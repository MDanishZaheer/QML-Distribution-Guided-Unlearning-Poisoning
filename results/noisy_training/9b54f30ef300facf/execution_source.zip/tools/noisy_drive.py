"""Fast local execution with verified Drive recovery for the noisy-only study.

This helper changes storage transport only. Model code, gradients, optimizer
states, seeds, numeric inputs and strict checkpoint identities are unchanged.
"""

from contextlib import ExitStack, contextmanager
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Condition, Lock, RLock, Thread
from time import monotonic
from unittest.mock import patch
from uuid import uuid4
from zipfile import ZIP_DEFLATED, ZipFile
import hashlib
import json
import os

from src import artifacts, checkpoints, noisy_training
from src.checkpoint_storage import CheckpointMirror, _read_checkpoint
from tools.colab_bootstrap import extract_checked


STAGES = ("noisy_supervised", "noisy_unlearning")


def _sha(content):
    return hashlib.sha256(content).hexdigest()


def _replace(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + "." + uuid4().hex + ".tmp")
    try:
        temporary.write_bytes(content)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _receipt(path):
    return path.with_name(path.name + ".sha256.json")


def _read_verified(path):
    content = path.read_bytes()
    if json.loads(_receipt(path).read_text())["sha256"] != _sha(content):
        raise ValueError("Drive recovery checksum mismatch: " + str(path))
    return content


def publish(path, content, *, previous=False):
    """Commit bytes and a receipt; keep a second state generation for recovery."""
    path = Path(path)
    if previous and path.exists():
        old = _read_verified(path)
        backup = path.with_name(path.name + ".previous")
        _replace(backup, old)
        _replace(_receipt(backup), json.dumps({"sha256": _sha(old)}).encode())
    _replace(path, content)
    # One full read-back is sufficient. Recovery separately verifies the receipt.
    if _sha(path.read_bytes()) != _sha(content):
        raise OSError("Drive write failed read-back verification: " + str(path))
    _replace(_receipt(path), json.dumps({"sha256": _sha(content)}).encode())
    if json.loads(_receipt(path).read_text())["sha256"] != _sha(content):
        raise OSError("Drive receipt failed read-back verification: " + str(path))


class DriveRecovery:
    """Per-update Adam backups, per-model archives, and a small metadata snapshot.

    Each optimizer commits every update locally. CheckpointMirror publishes a
    verified Drive generation every five seconds and flushes on normal exit.
    Completed model archives are verified on Drive BEFORE completion is reported.
    Routine metadata saves are coalesced in one background writer. New optimizer
    starts wait for durable metadata OUTSIDE the shared model-selection lock.
    A fresh VM restores the same version-1 archives used by the earlier helper.
    """

    def __init__(self, runtime_root, drive_root, *, emit=None):
        self.root = Path(runtime_root).resolve()
        self.drive = Path(drive_root).resolve()
        if self.root == self.drive:
            raise ValueError("Runtime-local and durable project roots must differ.")
        self.emit = emit or (lambda message: print(message, flush=True))
        self.lock = RLock()
        self.condition = Condition(self.lock)
        # Windows readers can prevent atomic replacement of an open JSON file.
        # This lock covers only local metadata reads/writes, never Drive I/O.
        self.metadata_lock = RLock()
        self.snapshot_lock = Lock()
        self.writer = None
        self.requested = self.committed = 0
        self.writer_error = None
        self.stopping = False
        self.pending_manifests = {}
        self.snapshots_written = 0
        self.catalog_file = self.root / ".transport/catalog.json"
        self.catalog = {"version": 1, "runs": {}}
        self.state = self.drive / "recovery/state.zip"

    def _relative(self, path):
        path = Path(path).resolve()
        if not path.is_relative_to(self.root):
            raise ValueError("Runtime output leaves its workspace.")
        return path.relative_to(self.root)

    def mirror(self, path, interval=5.0):
        relative = self._relative(path)
        if relative.parts[:3] not in (("results", "runs", stage) for stage in STAGES):
            raise ValueError("Only noisy-model optimizer checkpoints may be mirrored.")
        recovery = self

        class RecoveryMirror(CheckpointMirror):
            def __enter__(self):
                if recovery.writer is not None:
                    # _supervised/_unlearning have released the model-start lock
                    # here. Identity, source and frozen references must be durable
                    # before the first optimizer checkpoint is published.
                    recovery.snapshot()
                return super().__enter__()

            def _flush_unlocked(self):
                super()._flush_unlocked()
                # Retain the latest Adam state even if the metadata writer failed,
                # then let the existing cancellation callback stop the optimizer.
                recovery._check_writer()

        mirror = RecoveryMirror(self.drive / relative, interval=interval)
        mirror.enabled = True
        mirror.local = self.root / relative
        return mirror

    def restore(self, *, read_only=False):
        """Restore one metadata ZIP and one ZIP per completed model, with checksums."""
        candidates = (self.state, self.state.with_name(self.state.name + ".previous"))
        if not any(path.exists() for path in candidates):
            if any((self.drive / "results/runs" / stage).exists() for stage in STAGES):
                raise ValueError("Drive has noisy checkpoints but no verified recovery snapshot. "
                                 "Preserve those files and inspect them before starting a new attempt.")
            self.emit("No previous noisy attempt found; the completed noiseless inputs stay unchanged.")
            return
        errors = []
        for candidate in candidates:
            try:
                content = _read_verified(candidate)
                break
            except (OSError, ValueError, KeyError) as error:
                errors.append(error)
        else:
            raise ValueError("No verified metadata snapshot is recoverable; no fitting started.") from errors[-1]
        if candidate != self.state and not read_only:
            self.emit("Recovered the previous verified metadata generation; repairing its current copy.")
            publish(self.state, content)
        local = self.root / ".transport/restore.zip"
        _replace(local, content)
        with ZipFile(local) as bundle:
            for name in bundle.namelist():
                allowed = (name == ".transport/catalog.json" or name.startswith("results/noisy_training/")
                           or any(name.startswith("results/runs/" + stage + "/") for stage in STAGES))
                if not allowed:
                    raise ValueError("Recovery snapshot contains an unrelated path: " + name)
        extract_checked(local, self.root)
        self.catalog = artifacts.load_json(self.catalog_file)
        records = self.catalog["runs"]
        self.emit(f"Restoring {len(records)} completed noisy fits from verified Drive archives...")
        for i, (relative, record) in enumerate(sorted(records.items()), 1):
            run = self.root / relative
            cached = run / "manifest.json"
            ready = False
            if cached.exists():
                try:
                    artifacts.load_run(run)
                    ready = True
                except (ValueError, OSError, KeyError):
                    pass
            if not ready:
                archive = self.drive / record["archive"]
                if not archive.resolve().is_relative_to(self.drive):
                    raise ValueError("Recovery model archive leaves the Drive folder.")
                content = _read_verified(archive)
                if _sha(content) != record["sha256"]:
                    raise ValueError("Completed-model recovery archive changed.")
                _replace(local, content)
                with ZipFile(local) as bundle:
                    if any(not name.startswith(relative + "/") for name in bundle.namelist()):
                        raise ValueError("A model archive contains another model's files.")
                extract_checked(local, self.root)
                artifacts.load_run(run)
            if i % 10 == 0 or i == len(records):
                self.emit(f"Restored and verified {i}/{len(records)} completed fits.")
        for stage in STAGES:
            for manifest in sorted((self.root / "results/runs" / stage).glob("*/manifest.json")):
                if artifacts.load_json(manifest)["status"] == "complete":
                    continue
                self._register(manifest.parent)
                file = manifest.parent / "checkpoints/model.resume.json"
                if read_only:
                    generations = []
                    for candidate in (self.drive / self._relative(file),
                                      (self.drive / self._relative(file)).with_name(file.name + ".previous")):
                        if candidate.exists():
                            try:
                                saved, content = _read_checkpoint(candidate)
                                generations.append((saved["step"], content))
                            except (OSError, ValueError, KeyError):
                                pass
                    if not generations:
                        durable = self.drive / self._relative(file)
                        if durable.exists() or durable.with_name(file.name + ".previous").exists():
                            raise ValueError("No verified checkpoint generation is recoverable.")
                    else:
                        step, content = max(generations, key=lambda row: row[0])
                        _replace(file, content)
                        self.emit(f"Recovered {manifest.parent.name}: update {step} (read-only source).")
                    continue
                mirror = self.mirror(file)
                # Hydrate from the last verified Drive generation, including fallback.
                with mirror as hydrated:
                    if hydrated.exists():
                        self.emit(f"Recovered {manifest.parent.name}: update {artifacts.load_json(hydrated)['step']}.")
        self.emit("Recovery complete. Compatible finished fits will load; unfinished fits resume Adam/RNG state.")

    def _check_writer(self):
        with self.lock:
            if self.writer_error is not None:
                raise RuntimeError("Drive metadata backup failed; local checkpoints are preserved.") from self.writer_error

    def _register(self, path):
        """Remember a genuine unfinished manifest using local reads only."""
        path = Path(path)
        relative = self._relative(path).as_posix()
        content = (path / "manifest.json").read_bytes()
        if json.loads(content)["status"] == "complete":
            raise ValueError("An unfinished recovery registration requires an unfinished manifest.")
        with self.lock:
            self.pending_manifests[relative] = content

    def request_snapshot(self):
        """Schedule metadata persistence without holding up optimizer workers."""
        with self.condition:
            self._check_writer()
            self.requested += 1
            ticket = self.requested
            self.condition.notify_all()
            return ticket

    def _write_snapshot(self):
        """Serialize state uploads, with no model/catalog lock across Drive I/O."""
        with self.snapshot_lock:
            started = monotonic()
            with TemporaryDirectory(prefix="qml-drive-state-") as temporary:
                archive = Path(temporary) / "state.zip"
                with self.metadata_lock:
                    with self.lock:
                        catalog = {"version": 1, "runs": dict(self.catalog["runs"])}
                        pending = dict(self.pending_manifests)
                    artifacts.save_json(self.catalog_file, catalog)
                    files = set()
                    files.update(p for p in (self.root / "results/noisy_training").rglob("*")
                                 if p.is_file() and p.suffix != ".tmp" and p.name != "noisy_training_download.zip")
                    for stage in STAGES:
                        directory = self.root / "results/runs" / stage
                        files.update(directory.glob("active_checkpoints.json"))
                    # Completed models already have their own verified archives.
                    # Capture a genuine unfinished manifest until its archive has
                    # uploaded, even if the live manifest is already complete.
                    for relative in pending:
                        if relative not in catalog["runs"]:
                            files.update(self.root / relative / name for name in
                                         ("config.json", "provenance.json", "source.zip")
                                         if (self.root / relative / name).is_file())
                    with ZipFile(archive, "w", ZIP_DEFLATED) as bundle:
                        bundle.writestr(".transport/catalog.json", json.dumps(catalog))
                        for file in sorted(files):
                            bundle.write(file, self._relative(file).as_posix())
                        for relative, content in sorted(pending.items()):
                            if relative not in catalog["runs"]:
                                bundle.writestr(relative + "/manifest.json", content)
                publish(self.state, archive.read_bytes(), previous=True)
            self.snapshots_written += 1
            seconds = monotonic() - started
            if seconds >= 30:
                self.emit(f"Drive metadata snapshot verified ({seconds:.0f}s); other optimizers may continue.")

    def _writer_loop(self):
        while True:
            with self.condition:
                self.condition.wait_for(lambda: self.stopping or self.requested > self.committed)
                if self.stopping and self.requested == self.committed:
                    return
                # Merge bursts of per-model metadata saves into one upload.
                self.condition.wait(timeout=0.2)
                ticket = self.requested
            try:
                self._write_snapshot()
            except BaseException as error:
                with self.condition:
                    self.writer_error = error
                    self.condition.notify_all()
                return
            with self.condition:
                self.committed = ticket
                self.condition.notify_all()

    def snapshot(self):
        """Wait for a verified snapshot, including every save preceding this call."""
        if self.writer is None:
            return self._write_snapshot()
        ticket = self.request_snapshot()
        with self.condition:
            self.condition.wait_for(lambda: self.committed >= ticket or self.writer_error is not None)
            self._check_writer()

    def completed(self, path):
        started = monotonic()
        relative = self._relative(path).as_posix()
        artifacts.load_run(path)  # Verify the committed model before publishing.
        with TemporaryDirectory(prefix="qml-drive-model-") as temporary:
            archive = Path(temporary) / "model.zip"
            with ZipFile(archive, "w", ZIP_DEFLATED) as bundle:
                for file in sorted(Path(path).rglob("*")):
                    if file.is_file() and file.suffix != ".tmp":
                        bundle.write(file, self._relative(file).as_posix())
            content = archive.read_bytes()
        target = Path("recovery/models") / Path(relative).parent.name / (Path(relative).name + ".zip")
        # Independent completed-model uploads do not block new model selection.
        publish(self.drive / target, content)
        with self.lock:
            self.catalog["runs"][relative] = {"archive": target.as_posix(), "sha256": _sha(content)}
            self.pending_manifests.pop(relative, None)
        self.snapshot()  # The archive AND catalog must be durable before DONE.
        self.emit(f"Drive model archive and catalog verified: {Path(relative).name} ({monotonic()-started:.1f}s).")

    @contextmanager
    def active(self):
        """Use inside noisy_training_execution; never change the scientific source."""
        if self.writer is not None:
            raise RuntimeError("Drive recovery is already active.")
        for stage in STAGES:
            for file in (self.root / "results/runs" / stage).glob("*/manifest.json"):
                if artifacts.load_json(file)["status"] != "complete":
                    self._register(file.parent)
        provenance_file = self.root / "results/noisy_training/transport/provenance.json"
        if provenance_file.exists():
            old = provenance_file.read_bytes()
            _replace(provenance_file.with_name("provenance_" + _sha(old)[:16] + ".json"), old)
        artifacts.save_json(provenance_file, {
            "scope": "Storage transport only; no change to gradients, optimizer budgets or RNG streams.",
            "source_fingerprint": artifacts.source_fingerprint(self.root),
            "runtime_root": str(self.root), "durable_root": str(self.drive),
            "backup_interval_seconds": 5,
            "metadata_transport": "coalesced background snapshots; optimizer-start and completion durability barriers",
            "helper_sha256": {file.name: _sha(file.read_bytes())
                               for file in sorted((Path(__file__).parent).glob("*.py"))},
        })
        original_open = checkpoints.CheckpointSession.open
        original_save, original_finish = noisy_training.save_json, noisy_training.finish_run
        original_artifact_save = artifacts.save_json
        recovery = self

        def open_checkpoint(session, directory, *args, **kwargs):
            with recovery.metadata_lock:
                path, cached = original_open(session, directory, *args, **kwargs)
                if path is not None and cached is None:
                    recovery._register(path)
                    recovery.request_snapshot()  # Local queue only inside the model-start lock.
            return path, cached

        def save_metadata(path, value):
            with recovery.metadata_lock:
                original_save(path, value)
            recovery.request_snapshot()  # Coalesce protocol/teacher/index updates.

        def save_observer_metadata(path, value):
            # The heartbeat writes via artifacts, rather than the core runner's
            # alias above. Share the snapshot lock so Windows cannot archive a
            # diagnostic JSON while its atomic replacement is in progress.
            # Optimizer files use training's original alias and are unaffected.
            resolved = Path(path).resolve()
            if resolved.is_relative_to(recovery.root / "results/noisy_training"):
                with recovery.metadata_lock:
                    return original_artifact_save(path, value)
            return original_artifact_save(path, value)

        def finish(path, status, **details):
            with recovery.metadata_lock:
                original_finish(path, status, **details)
            if status == "complete":
                recovery.completed(path)
            else:
                recovery._register(path)
                recovery.request_snapshot()

        self._check_writer()
        self._write_snapshot()
        self.stopping = False
        self.writer = Thread(target=self._writer_loop, name="drive-metadata-backup", daemon=True)
        self.writer.start()
        self.emit("Drive recovery: background metadata uploads; verified model-start/completion barriers enabled.")
        with ExitStack() as stack:
            stack.enter_context(patch.object(checkpoints.CheckpointSession, "open", open_checkpoint))
            stack.enter_context(patch.object(noisy_training, "CheckpointMirror", self.mirror))
            stack.enter_context(patch.object(noisy_training, "save_json", save_metadata))
            stack.enter_context(patch.object(artifacts, "save_json", save_observer_metadata))
            stack.enter_context(patch.object(noisy_training, "finish_run", finish))
            try:
                yield self
            finally:
                try:
                    self.snapshot()  # Flush on completion and normal interruption.
                finally:
                    with self.condition:
                        self.stopping = True
                        self.condition.notify_all()
                    self.writer.join()
                    self.writer = None


def export_bundle(root, drive_root, *, filename="noisy_models_results.zip"):
    """Publish a normal-path ZIP of all completed/partial noisy outputs and code."""
    root, drive_root = Path(root).resolve(), Path(drive_root).resolve()
    if Path(filename).name != filename or not filename.endswith(".zip"):
        raise ValueError("Use a ZIP filename without directory components.")
    files = set()
    for directory in ("src", "tools", "results/noisy_training",
                      "results/runs/noisy_supervised", "results/runs/noisy_unlearning"):
        files.update(p for p in (root / directory).rglob("*")
                     if p.is_file() and p.suffix not in (".tmp", ".pyc")
                     and p.name != "noisy_training_download.zip")
    files.update(root / name for name in ("requirements.txt", "README.md", "main_project.ipynb", "input_manifest.json"))
    files.update(root.glob("*.ipynb"))
    with TemporaryDirectory(prefix="qml-noisy-export-") as temporary:
        archive = Path(temporary) / "noisy_models_results.zip"
        with ZipFile(archive, "w", ZIP_DEFLATED) as bundle:
            for file in sorted(files):
                if not file.resolve().is_relative_to(root):
                    raise ValueError("Export path leaves the runtime project.")
                bundle.write(file, file.relative_to(root).as_posix())
        target = drive_root / filename
        publish(target, archive.read_bytes())
    return target
