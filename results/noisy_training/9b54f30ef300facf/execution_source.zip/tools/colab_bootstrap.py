"""Colab setup and verified, runtime-local input staging (standard library only)."""

from importlib import metadata
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def install_dependencies(project, *, device="GPU"):
    """Install one Aer wheel; keep the archived requirements bytes unchanged.

    CPU runners substitute qiskit-aer at the same pinned version. Actual
    installed distributions are recorded by execution_environment(), not by
    relabelling an earlier GPU environment.
    """
    if device not in ("CPU", "GPU"):
        raise ValueError("Select CPU or GPU explicitly.")
    if platform.system() != "Linux" or platform.machine() != "x86_64":
        raise RuntimeError("This upload package targets an x86_64 Linux Colab runtime.")
    project = Path(project)
    pins = {}
    for line in (project / "requirements.txt").read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            name, version = line.split("==")
            pins[name] = version
    aer_package = "qiskit-aer-gpu" if device == "GPU" else "qiskit-aer"
    other_aer = "qiskit-aer" if device == "GPU" else "qiskit-aer-gpu"
    if device == "CPU":
        pins[aer_package] = pins.pop("qiskit-aer-gpu")
    missing = []
    for name, version in pins.items():
        try:
            installed = metadata.version(name)
        except metadata.PackageNotFoundError:
            installed = None
        if installed != version:
            missing.append(name)
    try:
        metadata.version(other_aer)
        conflicting_aer = True
    except metadata.PackageNotFoundError:
        conflicting_aer = False
    if not missing and not conflicting_aer:
        print("Pinned dependencies already installed; no installation repeated.", flush=True)
        return
    loaded = any(name in sys.modules for name in ("numpy", "scipy", "pandas", "qiskit", "qiskit_aer"))
    if conflicting_aer:
        subprocess.check_call([sys.executable, "-m", "pip", "uninstall", "-y", other_aer])
    subprocess.check_call([sys.executable, "-m", "pip", "install",
                           *[name + "==" + version for name, version in pins.items()]])
    if conflicting_aer:
        # The CPU and GPU wheels share import files. Repair files removed by uninstall.
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--force-reinstall", "--no-deps",
                               aer_package + "==" + pins[aer_package]])
    if loaded:
        raise RuntimeError("Installation finished. Use Runtime > Restart session, then Run all again. "
                           "This prevents mixing old imported libraries with the new environment.")
    print(f"Pinned {device} dependencies installed.", flush=True)


def extract_checked(archive, destination):
    """Reject archive traversal, duplicate paths and symlinks before extracting."""
    destination = Path(destination).resolve()
    with ZipFile(archive) as bundle:
        names = set()
        for member in bundle.infolist():
            path = PurePosixPath(member.filename)
            key = member.filename.casefold()
            if (path.is_absolute() or ".." in path.parts or "\\" in member.filename
                    or ":" in member.filename or key in names
                    or (member.external_attr >> 16) & 0o170000 == 0o120000):
                raise ValueError("Unsafe or duplicate archive member: " + member.filename)
            names.add(key)
            if not (destination / member.filename).resolve().is_relative_to(destination):
                raise ValueError("Archive member leaves its destination.")
        damaged = bundle.testzip()
        if damaged:
            raise ValueError("Archive CRC check failed: " + damaged)
        bundle.extractall(destination)


def stage_runtime(project, runtime_parent="/content/qml_noisy", *, emit=print):
    """Read the historical archive once, then verify/read its models on local disk."""
    project = Path(project).resolve()
    manifest = json.loads((project / "input_manifest.json").read_text())
    runtime = Path(runtime_parent).resolve() / manifest["archive_sha256"][:16]
    runtime.mkdir(parents=True, exist_ok=True)
    archive = runtime / "historical_inputs.zip"
    if not archive.exists() or digest(archive) != manifest["archive_sha256"]:
        emit("Copying the saved input archive from Drive to runtime-local disk...", flush=True)
        shutil.copyfile(project / "historical_inputs.zip", archive)
    if digest(archive) != manifest["archive_sha256"]:
        raise ValueError("Historical input archive checksum mismatch.")
    marker = runtime / ".historical_inputs_verified.json"
    if not marker.exists():
        emit("Checking and extracting saved numeric inputs locally...", flush=True)
        extract_checked(archive, runtime)
        for i, (relative, expected) in enumerate(manifest["files"].items(), 1):
            if digest(runtime / relative) != expected:
                raise ValueError("Historical artifact checksum mismatch: " + relative)
            if i % 1000 == 0:
                emit(f"Verified {i}/{len(manifest['files'])} input files.", flush=True)
        marker.write_text(json.dumps({"sha256": manifest["archive_sha256"]}))
    loaded_science = sys.modules.get("src")
    if loaded_science is not None:
        loaded_file = getattr(loaded_science, "__file__", None)
        if loaded_file is None or not Path(loaded_file).resolve().is_relative_to(runtime):
            raise RuntimeError("Scientific modules were imported from another workspace. "
                               "Restart the session and run this notebook from the beginning.")
        changed = any(not (runtime / source.relative_to(project)).exists()
                      or source.read_bytes() != (runtime / source.relative_to(project)).read_bytes()
                      for source in (project / "src").rglob("*.py"))
        if changed or ((runtime / "requirements.txt").exists()
                       and (project / "requirements.txt").read_bytes() != (runtime / "requirements.txt").read_bytes()):
            raise RuntimeError("Source or dependency pins changed after imports. Restart the session first.")
    # Copy code only, never overwrite recovered model results.
    for directory in ("src", "tools"):
        for source in sorted((project / directory).rglob("*.py")):
            target = runtime / source.relative_to(project)
            target.parent.mkdir(parents=True, exist_ok=True)
            if not target.exists() or source.read_bytes() != target.read_bytes():
                shutil.copyfile(source, target)
    for name in ("requirements.txt", "README.md", "main_project.ipynb", "input_manifest.json"):
        shutil.copyfile(project / name, runtime / name)
    for notebook in project.glob("*.ipynb"):
        if notebook.name != "main_project.ipynb":
            shutil.copyfile(notebook, runtime / notebook.name)
    # Limit BLAS pools before scientific imports; Aer gets separately tested threads.
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[name] = "1"
    emit(f"Runtime workspace: {runtime}\nDurable upload/output folder: {project}", flush=True)
    return runtime, manifest
