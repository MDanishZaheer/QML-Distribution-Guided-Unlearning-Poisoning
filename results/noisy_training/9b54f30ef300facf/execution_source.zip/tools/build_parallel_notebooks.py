"""Generate five fold runners and two coordination notebooks; never execute them."""

from copy import deepcopy
from pathlib import Path
import json
import textwrap


ROOT = Path(__file__).resolve().parents[1]


def md(text):
    return {"cell_type": "markdown", "metadata": {},
            "source": textwrap.dedent(text).strip().splitlines(keepends=True)}


def code(text):
    return {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [],
            "source": (textwrap.dedent(text).strip() + "\n").splitlines(keepends=True)}


def write(name, cells, **metadata):
    value = {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
             "language_info": {"name": "python"}, "colab": {"name": name}, "qml_parallel": metadata},
             "nbformat": 4, "nbformat_minor": 4}
    (ROOT / name).write_text(json.dumps(value, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")


def bootstrap(template, runtime_name):
    cells = deepcopy(template[1:7])
    for cell in cells:
        source = "".join(cell["source"])
        if cell["cell_type"] == "code":
            source = source.replace("stage_runtime(UPLOAD_ROOT)",
                                    f'stage_runtime(UPLOAD_ROOT, runtime_parent="/content/qml_noisy_{runtime_name}")')
        cell["source"] = source.splitlines(keepends=True)
    return cells


def build():
    template = json.loads((ROOT / "aer_serial.ipynb").read_text(encoding="utf-8"))["cells"]
    for fold in range(5):
        cells = deepcopy(template)
        for index, cell in enumerate(cells):
            source = "".join(cell["source"])
            if cell["cell_type"] == "code":
                if "drive.mount(" in source:
                    source = f"FOLD = {fold}  # This notebook owns this fold only.\n" + source
                    source = source.replace('UPLOAD_ROOT = Path("/content/drive/MyDrive") / DRIVE_FOLDER',
                        'UPLOAD_ROOT = Path("/content/drive/MyDrive") / DRIVE_FOLDER\nFOLD_ROOT = UPLOAD_ROOT / "parallel" / f"fold_{FOLD}"')
                source = source.replace("stage_runtime(UPLOAD_ROOT)",
                    'stage_runtime(UPLOAD_ROOT, runtime_parent=f"/content/qml_noisy_fold_{FOLD}")')
                source = source.replace("STUDY_FOLDS = (0, 1, 2, 3, 4)",
                    "STUDY_FOLDS = (FOLD,)\nFRESH_WORKER_COUNTS = (5, 8)  # Only fresh fits benchmark these; resume pins the recorded execution.")
                source = source.replace("from tools.noisy_drive import DriveRecovery\n\nrecovery = DriveRecovery(PROJECT_ROOT, UPLOAD_ROOT)\nrecovery.restore()",
                    "from tools.parallel_folds import fold_recovery\n\nrecovery = fold_recovery(PROJECT_ROOT, UPLOAD_ROOT, FOLD)")
                source = source.replace("verify_checkpoint_storage(UPLOAD_ROOT)", "verify_checkpoint_storage(FOLD_ROOT)")
                source = source.replace("primary_study = saved_study.select_rates(PRIMARY_RATES)",
                    "from tools.parallel_folds import select_review_fold\nprimary_study = select_review_fold(saved_study.select_rates(PRIMARY_RATES), FOLD)")
                source = source.replace("from tools.noisy_workflow import prepare_execution, locate_index",
                    "from tools.noisy_workflow import locate_index\nfrom tools.parallel_folds import prepare_fold_execution as prepare_execution")
                source = source.replace("training_noise, selected_index=noisy_index,",
                    "training_noise, selected_index=noisy_index, worker_counts=FRESH_WORKER_COUNTS,")
                source = source.replace('"/ 100"', '"/ 20"').replace('"/ 130"', '"/ 26"')
                source = source.replace("export_bundle(PROJECT_ROOT, UPLOAD_ROOT)", "export_bundle(PROJECT_ROOT, FOLD_ROOT)")
                cell.update(execution_count=None, outputs=[])
            else:
                source = source.replace("across all five folds", "within this assigned fold")
                source = source.replace("100 supervised + 130 unlearning = 230 fits", "20 supervised + 26 unlearning = 46 fits")
                source = source.replace("The queue interleaves folds.", "The queue runs independent models within this fold.")
                source = source.replace("The final archive contains", "This fold's final archive contains")
                source = source.replace("from the uploaded Drive folder", "from this fold's Drive folder")
                if index == 0:
                    source = f"""# Noisy training: fold {fold}

Run `parallel_setup.ipynb` once first, after stopping the old serial runner.
Open each `train_fold_N.ipynb` in its own independent GPU runtime. Run only
one writer for each fold; opening another tab on the same runtime adds no GPU.

This runner owns fold {fold}: 20 supervised and 26 unlearning fits. Multiple
independent model workers share Aer batching within this runtime. Seed 6304,
data, circuit, noise, training budgets and model checkpoint identities stay fixed.

Recovery and this fold's ZIP stay under `MyDrive/collab/parallel/fold_{fold}/`.
Completed compatible models load; unfinished models resume their full Adam/RNG
state. Changed source/environment/execution stops rather than resetting progress.
Use `parallel_results.ipynb` after all runners finish for the five-fold analysis.
"""
                if "Fold SD is descriptive" in source:
                    source += "\n\nThis runner contains one fold. Use the combined-results notebook for five-fold means and descriptive SD."
            cell["source"] = source.splitlines(keepends=True)
        write(f"train_fold_{fold}.ipynb", cells, role="fold_runner", fold=fold)

    shared = """
    from src.fresh_study import FreshStudy
    from tools.noisy_workflow import PRIMARY_RATES, validate_plan
    from src.noisy_training import load_training_problems
    import pandas as pd
    from IPython.display import display

    saved_study = FreshStudy(PROJECT_ROOT, PROJECT_ROOT / input_manifest["study_index"],
                             progress=lambda message: print(message, flush=True))
    primary_study = saved_study.select_rates(PRIMARY_RATES)
    problems, historical, bindings = load_training_problems(primary_study, (0, 1, 2, 3, 4), "all")
    plan_table = validate_plan(problems, bindings)
    display(plan_table.groupby(["fold", "stage"]).size().unstack(fill_value=0))
    """
    setup = [md("""
    # Prepare five independent fold runners

    Stop the current serial training cell normally and wait for backups to finish.
    Keep its original `recovery/` and `results/`. Upload the updated `tools/`
    folder and the seven new notebooks into the existing `MyDrive/collab/`.

    Run this notebook once. It only reads verified saved inputs and copies saved
    checkpoints into separate fold recovery folders. It never trains a model,
    downloads MNIST or changes the scientific source. The original recovery is
    read-only. A repeated setup keeps an existing parallel plan and its progress.
    """)] + bootstrap(template, "parallel_setup")
    setup += [md("""
    ## 3. Verify the unchanged study plan

    There are 46 distinct fits per fold: 20 supervised and 26 unlearning.
    Both attacks use 5/10/20/30/40/50%; the 25% ablation support is excluded.
    """), code(shared), md("""
    ## 4. Copy saved progress into separate fold recovery folders

    `LEGACY_INDEX=None` selects one original noisy study. If multiple attempts
    exist, select its relative `results/noisy_training/.../study.json` path.
    Original manifests, source hashes, environments, checkpoint bytes, fixed
    teachers and completed-model archives are retained. This is a storage handoff,
    not a new experimental result. No failed or missing score is filled in.
    """), code("""
    from src.models.noise import NoiseSetting
    from tools.parallel_folds import prepare_parallel

    LEGACY_INDEX = None
    parallel_plan = prepare_parallel(primary_study, UPLOAD_ROOT,
        legacy_index=LEGACY_INDEX, setting=NoiseSetting("combined", 0.01))
    display(pd.DataFrame(parallel_plan["initial_coverage"]))
    print("Ready plan:", parallel_plan["plan_id"])
    """), md("""
    ## 5. Start the separate GPU runtimes

    Open `train_fold_0.ipynb` through `train_fold_4.ipynb`, each connected to
    a separate GPU runtime. Begin with two to confirm allocation and combined
    throughput, then start the others if Colab provides the resources. Each
    runtime runs several model workers; fresh execution checks 5 and 8 workers.
    Resumed models pin their recorded worker/device/thread settings. Use the same
    GPU type and matching environment for unfinished checkpoints. A mismatch
    stops; keep the saved files and restore the matching runtime.

    Run one writer per fold. Keep `FORCE_RETRAIN=False`. Do not restart the old
    serial runner alongside these runners. After completion, use
    `parallel_results.ipynb`, then download `parallel_noisy_models_results.zip`.
    """)]
    write("parallel_setup.ipynb", setup, role="prepare")

    results = [md("""
    # Combine saved noisy results across five folds

    Run after the fold runners finish. This notebook only verifies and analyzes
    saved numeric results. It does not fit a model or generate quantum predictions.
    Each fold's recorded environment and execution provenance stay separate.
    Tables report all planned folds and never fill in missing experimental values.
    """)] + bootstrap(template, "parallel_results")
    results += [md("## 3. Verify the original experiment and expected coverage"), code(shared), md("""
    ## 4. Collect verified fold artifacts

    Keep `REQUIRE_COMPLETE=True` for the final report. Set False deliberately
    only to inspect available partial coverage. Missing folds stay missing and
    planned coverage still uses all five folds. Current source and original
    source/data/noise identities must match; completed numeric artifacts can be
    reviewed without matching the coordinator's current GPU environment.
    """), code("""
    from src.models.noise import NoiseSetting
    from src.evaluation.saved_results import protect_review
    from tools.parallel_folds import collect_parallel

    REQUIRE_COMPLETE = True
    with protect_review():
        noisy_index, noisy_tables = collect_parallel(
            primary_study, UPLOAD_ROOT, require_complete=REQUIRE_COMPLETE,
            setting=NoiseSetting("combined", 0.01),
        )
    print("Verified aggregate:", noisy_index)
    display(noisy_tables["coverage"].groupby(["training_regime", "deployment"])
            .completed.agg(["sum", "count"]))
    """), md("""
    ## 5. Compare retained performance, forgetting and retraining agreement

    Inspect retained accuracy, recalls of digits 0/1, digit-2 recall/confidence
    and full/conditional KL together. Behavioral suppression is not certified
    deletion. Fold SD is descriptive, and one seed does not establish independent
    seed uncertainty. Targets and paired training changes come from saved models.
    """), code("""
    metrics = ("retained_accuracy", "forget_recall", "forget_confidence", "recall_digit_0",
               "recall_digit_1", "full_kl_mean", "conditional_kl_mean")
    display(noisy_tables["fold_summary"].loc[lambda table: table.metric.isin(metrics)].round(4))
    """), code("""
    display(noisy_tables["targets"].round(4))
    display(noisy_tables["training_change_fold_summary"].round(4))
    """), md("## 6. Show all generated comparison figures"), code("""
    import matplotlib.pyplot as plt
    from src.evaluation.noisy_training_analysis import noisy_training_figures

    figures = noisy_training_figures(noisy_tables)
    for name, figure in figures.items():
        print(name)
        display(figure)
        plt.close(figure)
    """), md("""
    ## 7. Save tables, figures and one combined results archive

    Export the already loaded tables. The ZIP uses conventional relative
    `results/` paths and preserves all five fold source indexes/provenance.
    Download `parallel_noisy_models_results.zip` from `MyDrive/collab/`.
    Keep the fold recovery folders and original serial recovery until import
    into the parent project has been verified. This aggregate is for review;
    optimizer continuation always uses the assigned fold runner.
    """), code("""
    from src.evaluation.noisy_training_analysis import export_noisy_training
    from tools.noisy_drive import export_bundle

    analysis_directory = export_noisy_training(noisy_index, PROJECT_ROOT, figures, tables=noisy_tables)
    print("Tables and figures:", analysis_directory)
    result_archive = export_bundle(PROJECT_ROOT, UPLOAD_ROOT, filename="parallel_noisy_models_results.zip")
    print("Verified combined archive:", result_archive)
    """)]
    write("parallel_results.ipynb", results, role="saved_review")
    build_cpu(template, shared)
    print("Wrote GPU and CPU fold runners plus their setup/results notebooks; no notebook executed.")


def build_cpu(template, shared):
    """Keep GPU runners available; CPU runtimes have separate notebooks/stores."""
    for fold in range(5):
        cells = json.loads((ROOT / f"train_fold_{fold}.ipynb").read_text(encoding="utf-8"))["cells"]
        for index, cell in enumerate(cells):
            source = "".join(cell["source"])
            if cell["cell_type"] == "code":
                source = source.replace('UPLOAD_ROOT / "parallel"', 'UPLOAD_ROOT / "parallel_cpu"')
                source = source.replace('install_dependencies(UPLOAD_ROOT)', 'install_dependencies(UPLOAD_ROOT, device="CPU")')
                source = source.replace('/content/qml_noisy_fold_', '/content/qml_noisy_cpu_fold_')
                source = source.replace('FRESH_WORKER_COUNTS = (5, 8)  # Only fresh fits benchmark these; resume pins the recorded execution.',
                                        '# Fresh CPU workers and Aer threads follow the allocated CPU quota.')
                source = source.replace('from tools.parallel_folds import fold_recovery',
                                        'from tools.cpu_folds import cpu_fold_recovery as fold_recovery')
                source = source.replace('from tools.parallel_folds import prepare_fold_execution as prepare_execution',
                                        'from tools.cpu_folds import prepare_cpu_execution as prepare_execution, cpu_completed_models')
                source = source.replace(', worker_counts=FRESH_WORKER_COUNTS', '')
                if index == 8:
                    source = """import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display
from qiskit_aer import AerSimulator
from src.execution_resources import host_resources
from src.ablations import execution_environment
from tools.cpu_folds import allocated_cores, cpu_candidates

print("Aer devices:", AerSimulator().available_devices())
print("Usable CPU cores:", allocated_cores())
display(pd.Series(host_resources(), name="Allocated resources"))
display(pd.DataFrame([vars(candidate) for candidate in cpu_candidates()]))
display(pd.Series(execution_environment(), name="Actual CPU runtime"))
"""
                if 'noisy_index = run_noisy_training(' in source:
                    source = source.replace('with noisy_training_monitor(PROJECT_ROOT, heartbeat_seconds=30):',
                        'with noisy_training_monitor(PROJECT_ROOT, heartbeat_seconds=30), cpu_completed_models(PROJECT_ROOT):')
            else:
                source = source.replace('same GPU/runtime environment', 'same CPU/runtime environment')
                if index == 0:
                    source = f"""# Noisy training on CPU: fold {fold}

Run `cpu_parallel_setup.ipynb` once first. Use Runtime > Change runtime type >
CPU, then run this notebook. Each `train_cpu_fold_N.ipynb` needs its own
independent runtime; extra tabs on one runtime do not add CPU resources.

This fold has 20 supervised and 26 unlearning fits. Fresh execution benchmarks
worker/thread choices bounded by the allocated CPU cores. Seed 6304, data,
circuit, exact noise and training budgets stay fixed.

Completed GPU models are verified and reused with their original provenance.
Unfinished GPU Adam states stay at their source: CPU replacements initialize
afresh. Unfinished CPU fits subsequently resume their full matching Adam/RNG
state. Storage is `MyDrive/collab/parallel_cpu/fold_{fold}/`; GPU stores remain
separate. Use `cpu_parallel_results.ipynb` for the combined five-fold analysis.
"""
                if index == 3:
                    source = """### 1.1 Install the pinned CPU libraries

The installer uses CPU Aer at the same pinned Aer version. It removes a
conflicting GPU Aer wheel and keeps the archived requirements file unchanged.
If a restart is requested, use Runtime > Restart session, then Run all again.
Actual installed packages are recorded separately from imported GPU provenance.
"""
                if index == 7:
                    source = """### 2.1 Check the allocated CPU resources

CPU mode does not require CUDA or a GPU. Core detection respects Linux CPU
affinity and cgroup quotas. A bounded benchmark measures optimizer throughput;
more RAM or workers alone does not establish a speedup.
"""
                if index == 13:
                    source = """## 4. Recover this CPU fold's checkpoints

Restore verified completed imports and any CPU optimizer backups. Imported
GPU checkpoints remain immutable. Only matching CPU optimizer states resume;
changed source, environment, execution or data stops without resetting progress.
"""
                if index == 25:
                    source = """## 7. Measure CPU execution throughput

Fresh CPU studies test at most three core-aware worker/thread configurations.
They check numeric agreement and measure one optimizer update, selecting by
throughput. These are performance probes, not completed research models.
Reconnects preserve the recorded execution and reuse a passing benchmark.
Do not raise worker counts beyond the allocated CPU quota.
"""
                if index == 27:
                    source += "\n\nVerified completed GPU fits load without optimization. Their exact saved teachers are retained when applicable. CPU replacements for unfinished GPU fits start from seed initialization; their original GPU states are preserved."
            cell["source"] = source.splitlines(keepends=True)
        write(f"train_cpu_fold_{fold}.ipynb", cells, role="cpu_fold_runner", fold=fold, device="CPU")

    def cpu_bootstrap(name):
        cells = bootstrap(template, name)
        for cell in cells:
            source = "".join(cell["source"])
            source = source.replace('install_dependencies(UPLOAD_ROOT)', 'install_dependencies(UPLOAD_ROOT, device="CPU")')
            source = source.replace('### 1.1 Install the pinned GPU libraries', '### 1.1 Install the pinned CPU libraries')
            if cell["cell_type"] == "markdown" and 'GPU-enabled Aer' in source:
                source = """### 1.1 Install the pinned CPU libraries

Use CPU Aer at the same pinned version; actual CPU package provenance is
recorded. Restart the session if requested, then Run all again.
"""
            cell["source"] = source.splitlines(keepends=True)
        return cells

    cells = [md("""
    # Prepare five independent CPU fold runners

    Stop the old GPU writer normally and wait for Drive backups to finish before
    running setup. Upload the updated `tools/` folder and the seven CPU notebooks
    into the existing `MyDrive/collab/`. Keep `src/`, `requirements.txt`, historical
    inputs, `recovery/` and any GPU `parallel/` folder.

    This setup reads the existing recovery store, preferring GPU fold stores
    when a GPU parallel plan exists. It copies verified completed fits into
    `parallel_cpu/fold_N/`. It never trains or edits the original GPU stores.
    Repeating setup retains the CPU plan and subsequent progress.
    """)] + cpu_bootstrap("cpu_setup")
    cells += [md("## 3. Verify the unchanged five-fold plan"), code(shared), md("""
    ## 4. Preserve GPU progress and create the CPU stores

    A device change cannot resume an unfinished GPU optimizer under the strict
    checkpoint rules. `RESTART_UNFINISHED_ON_CPU=True` deliberately starts new
    CPU replacements for those models. Original GPU partial checkpoints remain
    untouched, and completed GPU models are reused. Set False to stop setup if
    partial source fits exist. This does not force-retrain completed models.
    The displayed table records how many completed models can be reused and
    how many partial GPU updates remain preserved at their source.
    """), code("""
    from src.models.noise import NoiseSetting
    from tools.cpu_folds import prepare_cpu_parallel

    RESTART_UNFINISHED_ON_CPU = True  # Explicit device switch; GPU originals stay untouched.
    LEGACY_INDEX = None
    cpu_plan = prepare_cpu_parallel(primary_study, UPLOAD_ROOT,
        restart_unfinished=RESTART_UNFINISHED_ON_CPU, legacy_index=LEGACY_INDEX,
        setting=NoiseSetting("combined", 0.01))
    display(pd.DataFrame(cpu_plan["initial_coverage"]))
    print("Ready CPU plan:", cpu_plan["plan_id"])
    """), md("""
    ## 5. Start separate CPU runtimes

    Open `train_cpu_fold_0.ipynb` through `train_cpu_fold_4.ipynb`, each on a
    separate CPU runtime if your account can allocate them. One writer per fold.
    Begin with two runtimes and inspect the measured updates per second before
    starting the remaining folds. Each runtime benchmarks its own allocated cores;
    a shared runtime or extra browser tab does not supply additional CPU capacity.

    Keep `FORCE_RETRAIN=False`. Run all in each assigned notebook. Reconnect to
    the same package/device environment to resume CPU Adam/RNG checkpoints.
    When all five folds finish, run `cpu_parallel_results.ipynb`.
    """)]
    write("cpu_parallel_setup.ipynb", cells, role="cpu_prepare", device="CPU")

    cells = json.loads((ROOT / "parallel_results.ipynb").read_text(encoding="utf-8"))["cells"]
    for cell in cells:
        source = "".join(cell["source"])
        source = source.replace('install_dependencies(UPLOAD_ROOT)', 'install_dependencies(UPLOAD_ROOT, device="CPU")')
        source = source.replace('/content/qml_noisy_parallel_results', '/content/qml_noisy_cpu_results')
        source = source.replace('from tools.parallel_folds import collect_parallel', 'from tools.cpu_folds import collect_cpu_parallel as collect_parallel')
        source = source.replace('parallel_noisy_models_results.zip', 'cpu_parallel_noisy_models_results.zip')
        if cell["cell_type"] == "markdown" and 'GPU-enabled Aer' in source:
            source = """### 1.1 Install the pinned CPU libraries

Use CPU Aer at the pinned version. Restart if requested, then Run all.
"""
        if cell is cells[0]:
            source = source.replace('# Combine saved noisy results across five folds', '# Combine saved CPU-fold noisy results')
            source += "\n\nRead `parallel_cpu/` only. Reused completed GPU models retain their actual training identities; new CPU fits and fold runtime provenance are recorded separately. No mixed-device optimizer continuation is claimed."
        cell["source"] = source.splitlines(keepends=True)
    write("cpu_parallel_results.ipynb", cells, role="cpu_saved_review", device="CPU")


if __name__ == "__main__":
    build()
