"""Build the short, sequential noisy-only execution notebook (no execution)."""

from pathlib import Path
import json
import textwrap


def build(name="aer_serial.ipynb"):
    cells = []

    def md(text):
        cells.append({"cell_type": "markdown", "metadata": {},
                      "source": textwrap.dedent(text).strip().splitlines(keepends=True)})

    def code(text):
        cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [],
                      "source": (textwrap.dedent(text).strip() + "\n").splitlines(keepends=True)})

    md("""
    # Training and unlearning under simulated quantum noise

    This notebook runs the missing noisy study only. It loads the completed
    noiseless study as fixed inputs and comparisons. It does not repeat the
    original training, parameter ablations, data preparation, or noise sweeps.

    Upload the complete `collab` folder to `MyDrive`, select a GPU runtime with
    high RAM, open this notebook, and run it in order. Keep the folder name
    `collab`, or change the single path setting below. Package installation may
    request one session restart; run all again after that restart.
    """)
    md("""
    ## 1. Connect the durable project folder

    Drive stores verified optimizer backups and completed model archives.
    Circuit execution and repeated input reads use runtime-local disk.
    """)
    code("""
    from pathlib import Path
    import sys
    from google.colab import drive

    DRIVE_FOLDER = "collab"  # Folder uploaded directly inside MyDrive.
    drive.mount("/content/drive")
    UPLOAD_ROOT = Path("/content/drive/MyDrive") / DRIVE_FOLDER
    if not (UPLOAD_ROOT / "input_manifest.json").is_file():
        raise FileNotFoundError(f"Upload the full folder first: {UPLOAD_ROOT}")
    sys.path.insert(0, str(UPLOAD_ROOT))
    print("Durable project folder:", UPLOAD_ROOT)
    """)
    md("""
    ### 1.1 Install the pinned GPU libraries

    This package uses GPU-enabled Aer on Linux. The installer skips matching
    versions and removes a conflicting CPU Aer wheel. If it asks for a restart,
    use **Runtime > Restart session**, then **Run all** again. Keep these package
    versions fixed when resuming an unfinished optimizer.
    """)
    code("""
    from tools.colab_bootstrap import install_dependencies

    install_dependencies(UPLOAD_ROOT)
    """)
    md("""
    ## 2. Stage the verified inputs locally

    The supplied archive contains the exact saved folds, PCA features, labels,
    weights, predictions and model provenance. No MNIST download or PCA fitting
    is needed. Inputs are checksum-verified; missing or changed inputs stop here.
    """)
    code("""
    from tools.colab_bootstrap import stage_runtime
    import os

    PROJECT_ROOT, input_manifest = stage_runtime(UPLOAD_ROOT)
    sys.path.insert(0, str(PROJECT_ROOT))
    os.chdir(PROJECT_ROOT)
    print("Historical study:", input_manifest["study_index"])
    """)
    md("""
    ### 2.1 Check the allocated GPU and high RAM

    The run requires an actual Aer GPU device. Five or more independent
    optimizers share batched circuit execution. Memory usage is not a speed
    target: the short benchmark selects optimizer throughput, not VRAM occupancy.
    """)
    code("""
    import pandas as pd
    import matplotlib.pyplot as plt
    from IPython.display import display
    from qiskit_aer import AerSimulator
    from src.models.parallel_aer import gpu_sample, require_gpu
    from src.execution_resources import host_resources
    from src.ablations import execution_environment

    require_gpu()
    print("Aer devices:", AerSimulator().available_devices())
    display(pd.Series({**host_resources(), **gpu_sample()}, name="Allocated resources"))
    display(pd.Series(execution_environment(), name="Recorded runtime"))
    """)
    md("""
    ## 3. Set the execution controls

    `FORCE_RETRAIN=False` loads compatible completed noisy models and resumes
    interrupted ones from full Adam/RNG state. It does not repeat noiseless
    training. Restart the kernel before changing source, noise settings or modes.
    The 25% noiseless conditions are ablation support and are excluded here by
    the selected primary-study protocol. There is no saved 15% condition.
    """)
    code("""
    from src.config import DEFAULT_SEED
    from src.models.noise import NoiseSetting
    from tools.noisy_workflow import PRIMARY_RATES

    SEED = DEFAULT_SEED  # 6304 for every model and deterministic derived stream.
    STUDY_FOLDS = (0, 1, 2, 3, 4)
    RUN_NOISY_TRAINING = True
    FORCE_RETRAIN = False
    NOISY_TRAINING_INDEX = None  # Auto-discover one compatible saved attempt.
    SHOW_ANALYSIS = True
    EXPORT_RESULTS = True
    training_noise = NoiseSetting("combined", 0.01)
    print("Seed:", SEED, "| poisoning rates:", PRIMARY_RATES)
    """)
    md("""
    ### 3.1 Keep data poisoning and circuit noise separate

    Label flipping changes selected training labels from 0 to 2. Feature
    randomization replaces selected digit-2 inputs with normalized Gaussian
    vectors while preserving labels. Both reuse their exact saved inputs.

    Every new fit also includes synthetic gate/readout noise during optimization:
    one-qubit depolarizing strength 0.01, two-qubit strength 0.02, and symmetric
    readout flips 0.01. Density-matrix expectations integrate these channels
    exactly; optimization does not sample 2,048 shots. This is a declared
    synthetic profile, not a calibrated IBM device.
    """)
    code("""
    display(pd.Series(training_noise.describe(), name="Training noise").to_frame())
    """)
    md("""
    ## 4. Recover existing noisy checkpoints

    A new VM restores a small metadata snapshot and verified completed-model
    archives. Active optimizers recover the latest verified Drive backup. This
    avoids a recursive scan of all historical checkpoints. A mismatched source,
    runtime, execution setting or data identity stops rather than silently
    replacing an unfinished study.
    """)
    code("""
    from tools.noisy_drive import DriveRecovery

    recovery = DriveRecovery(PROJECT_ROOT, UPLOAD_ROOT)
    recovery.restore()
    """)
    md("""
    ### 4.1 Verify writable durable storage

    This small storage probe is not a model experiment. Adam state is committed
    locally after each update, mirrored to Drive every five seconds, and flushed
    on a normal interruption. Abrupt VM loss can lose updates since the last
    successful backup. Completed models are archived and verified before the
    notebook reports them as finished.
    """)
    code("""
    from src.checkpoint_storage import verify_checkpoint_storage

    storage_check = verify_checkpoint_storage(UPLOAD_ROOT)
    display(pd.Series(storage_check, name="Durable storage check"))
    """)
    md("""
    ## 5. Load the completed noiseless study

    Restore the original model artifacts and fold membership on local disk.
    Hash checks preserve their actual Linux/GPU training provenance. These
    models provide saved preprocessing, exact forget/anchor/calibration
    membership and matched comparisons; their weights are not used as the
    initial weights for new noisy supervised training.
    """)
    code("""
    from src.fresh_study import FreshStudy

    saved_study = FreshStudy(
        PROJECT_ROOT, PROJECT_ROOT / input_manifest["study_index"],
        progress=lambda message: print(message, flush=True),
    )
    primary_study = saved_study.select_rates(PRIMARY_RATES)
    print("Selected condition/fold pairs:", len(primary_study.conditions))
    """)
    md("""
    ### 5.1 Display the circuit used by every fit

    Keep the original six-qubit circuit, four PCA inputs, two reuploads, three
    ansatz repetitions, and 72 nominal trainable parameters.
    """)
    code("""
    from src.models.circuits import build_malik_circuit

    first_condition = next(iter(primary_study.conditions.values()))
    from src.config import CircuitConfig
    circuit = build_malik_circuit(CircuitConfig(**first_condition["config"]["circuit"]))
    figure = circuit.draw(output="mpl", fold=70)
    display(figure)
    plt.close(figure)
    """)
    md("""
    ## 6. Check the full noisy-training plan

    Cover clean and both attacks at 5/10/20/30/40/50% across all five folds.
    Each condition has an original classifier, matched retained-data retraining
    reference, guided unlearning and uniform unlearning. Identical retained
    training problems are reused: **100 supervised + 130 unlearning = 230 fits**.
    """)
    code("""
    from src.noisy_training import load_training_problems
    from tools.noisy_workflow import validate_plan

    noisy_problems, historical_inputs, noisy_bindings = load_training_problems(
        primary_study, STUDY_FOLDS, "all"
    )
    fit_plan = validate_plan(noisy_problems, noisy_bindings, STUDY_FOLDS)
    display(fit_plan.groupby(["fold", "stage"]).size().unstack(fill_value=0))
    print("Total new noisy fits:", len(fit_plan))
    """)
    md("""
    ### 6.1 Confirm every poisoning condition is present

    Poison percentages use the eligible class, not the whole training fold.
    Validation/test data and all saved numeric features stay fixed. Supervised
    fits use 300 updates and batch size 10; unlearning uses 100 updates.
    """)
    code("""
    display(noisy_bindings[["condition", "attack", "poison_rate", "fold"]]
            .drop_duplicates().groupby(["condition", "attack", "poison_rate"])
            .size().rename("planned_folds").to_frame())
    """)
    md("""
    ## 7. Check a short parallel execution benchmark

    A fresh study tests two bounded GPU configurations, with 5 and 8 optimizer
    workers. It checks probability/gradient agreement with CPU and selects
    measured update throughput. This is a short performance probe, not a
    reported research fit. A resumed study reuses its exact compatible execution
    and already-passing benchmark. Progress and Aer counters print every 30 seconds.
    """)
    code("""
    from src.noisy_training import noisy_training_execution
    from tools.noisy_training_runtime import noisy_training_monitor
    from tools.noisy_workflow import prepare_execution, locate_index

    noisy_index = locate_index(PROJECT_ROOT, NOISY_TRAINING_INDEX)
    if RUN_NOISY_TRAINING:
        with noisy_training_execution(PROJECT_ROOT), recovery.active():
            with noisy_training_monitor(PROJECT_ROOT, heartbeat_seconds=30):
                execution, benchmark, performance_directory = prepare_execution(
                    primary_study, noisy_problems, historical_inputs, noisy_bindings,
                    training_noise, selected_index=noisy_index,
                )
        display(benchmark)
    """)
    md("""
    ## 8. Train only the missing noisy models

    Supervised fits start from seed-6304 initialization. Then each noisy original
    supplies a newly frozen noisy teacher for guided/uniform unlearning. Both
    methods start from that same noisy original. Each fold/optimizer keeps its
    own weights, RNG, Adam moments and checkpoint; shared batching does not mix
    their training state. The queue interleaves folds.

    **Progress:** START identifies a model, STEP reports evaluated updates, and
    the heartbeat reads the latest locally committed update and Aer job counters.
    FITS counts completed or reused models only. A 10-minute lack of observed
    progress saves thread stacks as a possible-stall diagnostic. Interrupting
    normally flushes checkpoints; reconnecting reuses completed fits.
    """)
    code("""
    from src.noisy_training import run_noisy_training
    from tools.noisy_workflow import progress

    if RUN_NOISY_TRAINING:
        with noisy_training_execution(PROJECT_ROOT), recovery.active():
            with noisy_training_monitor(PROJECT_ROOT, heartbeat_seconds=30):
                noisy_index = run_noisy_training(
                    primary_study, noisy_problems, historical_inputs, noisy_bindings, execution,
                    setting=training_noise, allow_training=True, force_retrain=FORCE_RETRAIN,
                    performance_directory=performance_directory, progress=progress,
                )
    print("Noisy study index:", noisy_index)
    """)
    md("""
    ## 9. Inspect actual completion and coverage

    No missing result is fabricated. An interrupted study can be reviewed with
    explicit coverage. If training is disabled, analysis requires an existing
    index. All reported comparisons use matched ideal/noisy deployment and
    matched retained-data retraining references.
    """)
    code("""
    from src.artifacts import load_json

    if noisy_index is None:
        raise FileNotFoundError("No noisy study is available yet. Enable its training stage.")
    noisy_record = load_json(noisy_index)
    print("Study complete:", noisy_record["complete"])
    print("Supervised fits:", len(noisy_record["supervised"]), "/ 100")
    print("Unlearning fits:", len(noisy_record["unlearned"]), "/ 130")
    """)
    md("""
    ## 10. Compare the saved predictions

    Keep results from noiseless-trained and noisy-trained models separate.
    Compare both under ideal and noisy deployment. Retained accuracy concerns
    digits 0/1; forgotten recall/confidence concerns digit 2. KL is
    reference-to-candidate on clean retained test records. Noise can flatten
    probabilities and reduce KL without repairing classification, so inspect
    the metrics together. Fold SD is descriptive; these are not independent seeds.
    """)
    code("""
    from src.evaluation.noisy_training_analysis import noisy_training_tables

    noisy_tables = None
    if SHOW_ANALYSIS:
        print("Reading noisy predictions once and building comparison tables...", flush=True)
        _, noisy_tables = noisy_training_tables(noisy_index, PROJECT_ROOT)
        display(noisy_tables["coverage"].groupby(["training_regime", "deployment"])
                .completed.agg(["sum", "count"]))
    """)
    md("""
    ### 10.1 Retained accuracy and forgotten-class behavior

    Inspect all primary rates, both attacks, every role and both deployment
    settings. Low digit-2 recall is behavioral suppression; it does not by itself
    establish equality with retraining or certified deletion.
    """)
    code("""
    if noisy_tables is not None:
        metrics = ("retained_accuracy", "forget_recall", "forget_confidence",
                   "recall_digit_0", "recall_digit_1", "conditional_kl_mean")
        summary = noisy_tables["fold_summary"]
        display(summary.loc[summary.metric.isin(metrics)].round(4))
    """)
    md("""
    ### 10.2 Fixed guided/uniform targets and paired training changes

    Targets must come from each new noisy original's training-only calibration
    records. Compare changes within a fold before summarizing them. Do not treat
    reused retraining references as additional independent observations.
    """)
    code("""
    if noisy_tables is not None:
        display(noisy_tables["targets"].round(4))
        display(noisy_tables["training_change_fold_summary"].round(4))
    """)
    md("""
    ### 10.3 Display and save comparison figures

    Detailed clean/50% panels and poisoning-rate curves complement the full
    tables. Every generated figure is displayed here and saved for reporting.
    """)
    code("""
    from src.evaluation.noisy_training_analysis import noisy_training_figures

    noisy_figures = {}
    if noisy_tables is not None:
        noisy_figures = noisy_training_figures(noisy_tables)
        for name, figure in noisy_figures.items():
            print(name)
            display(figure)
            plt.close(figure)
    """)
    md("""
    ## 11. Export the actual results to Drive

    Tables/figures use the already loaded analysis. The final archive contains
    normal relative `results/noisy_training/` and `results/runs/noisy_*` paths,
    model/source provenance, and optimizer checkpoints. Download
    `noisy_models_results.zip` from the uploaded Drive folder for later import
    into the parent project. The recovery folder remains useful if a session
    expires before this final cell. Keep it until the study has been imported.
    """)
    code("""
    from src.evaluation.noisy_training_analysis import export_noisy_training
    from tools.noisy_drive import export_bundle

    if EXPORT_RESULTS:
        if noisy_tables is not None:
            analysis_directory = export_noisy_training(
                noisy_index, PROJECT_ROOT, noisy_figures, tables=noisy_tables
            )
            print("Analysis:", analysis_directory)
        recovery.snapshot()
        result_archive = export_bundle(PROJECT_ROOT, UPLOAD_ROOT)
        print("Verified results archive on Drive:", result_archive)
    """)
    md("""
    ## 12. Resume or review later

    For a new session, choose the same GPU/runtime environment and run this
    notebook again with `FORCE_RETRAIN=False`. Finished compatible fits load;
    unfinished fits resume their last verified Adam/RNG backup. If strict
    identity checks stop the run, restore the matching source/packages/device
    rather than deleting checkpoints or forcing retraining.

    To review a completed noisy study without fitting, set
    `RUN_NOISY_TRAINING=False` and rerun from a fresh kernel. No noiseless stage,
    MNIST download, or original parameter-ablation training is invoked here.
    """)
    notebook = {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                  "language_info": {"name": "python"}, "colab": {"name": "main_project.ipynb"}},
                "nbformat": 4, "nbformat_minor": 4}
    notebook["metadata"]["colab"]["name"] = name
    target = Path(__file__).resolve().parents[1] / name
    target.write_text(json.dumps(notebook, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    print("Wrote", len(cells), "unexecuted notebook cells.")


if __name__ == "__main__":
    build()
