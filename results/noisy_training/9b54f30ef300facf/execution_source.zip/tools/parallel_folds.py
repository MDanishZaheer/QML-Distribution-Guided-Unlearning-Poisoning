"""Partition noisy fits by fold, retain strict resume, and collect saved results.

Only orchestration/storage changes live here. src/ and the fitting identities
are unchanged. Each fold has one writer runtime and its own Drive recovery root.
"""

from copy import copy
from dataclasses import asdict
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import json
import shutil

from src import artifacts, noisy_training
from src.config import DEFAULT_SEED
from src.checkpoint_storage import _publish_checkpoint
from src.models.noise import NoiseSetting
from tools.noisy_drive import DriveRecovery, STAGES, _read_verified, publish
from tools.noisy_workflow import locate_index, prepare_execution


FOLDS = (0, 1, 2, 3, 4)
COMMON = ("code_fingerprint", "environment", "execution", "training_noise", "seed")


def _fold(value):
    if isinstance(value, bool) or value not in FOLDS or not isinstance(value, int):
        raise ValueError("Choose one integer fold from 0 through 4.")
    return value


def _local(root, relative):
    root = Path(root).resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Parallel artifact path leaves its workspace.")
    return path


def _json_publish(path, value):
    publish(path, json.dumps(artifacts.json_value(value), indent=2, sort_keys=True).encode())


def _verified_json(path):
    return json.loads(_read_verified(Path(path)))


def _copy_files(source, target):
    """Import immutable bytes; a conflicting existing artifact stops collection."""
    source, target = Path(source), Path(target)
    if not source.exists() and source.suffix:
        raise FileNotFoundError(source)
    files = [source] if source.is_file() else sorted(p for p in source.rglob("*") if p.is_file())
    for file in files:
        if file.suffix == ".tmp":
            continue
        destination = target if source.is_file() else target / file.relative_to(source)
        if destination.exists():
            if artifacts._file_digest(destination) != artifacts._file_digest(file):
                raise ValueError("Conflicting saved parallel artifact: " + str(destination))
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(file, destination)


def select_review_fold(review, fold):
    fold = _fold(fold)
    selected = copy(review)
    selected.conditions = {key: value for key, value in review.conditions.items()
                           if value["config"]["data"]["fold"] == fold}
    selected.split_paths = {fold: review.split_paths[fold]}
    if not selected.conditions:
        raise ValueError("The historical study has no conditions for this fold.")
    return selected


def _inputs(review, folds):
    return noisy_training.load_training_problems(review, tuple(folds), "all")


def _protocol(review, problems, historical, bindings, common):
    # This is the unchanged core runner's protocol, with only the selected input
    # membership reduced. It does not change any per-model fitting identity.
    return {**common, "original_report": review.report_path.relative_to(review.root).as_posix(),
            "original_source": review.source_fingerprint, "bindings": bindings.to_dict("records"),
            "problems": [p.key for p in problems], "plan": noisy_training.training_plan(problems).to_dict("records"),
            "historical_inputs": {key: model.identity(review.root) for key, model in historical.items()},
            "preprocessing": "frozen historical training-fitted PCA; no refit",
            "training_expectations": "exact noisy density matrix",
            "protocol_note": "New supervised fits start from seed-6304 initialization; new noisy teachers are frozen before unlearning."}


def _check_protocol(actual, expected):
    for key, value in expected.items():
        if artifacts.fingerprint(actual.get(key)) != artifacts.fingerprint(value):
            raise ValueError("Saved noisy protocol differs from the selected experiment: " + key)


def _state_bytes(drive_root):
    state = Path(drive_root) / "recovery/state.zip"
    for candidate in (state, state.with_name("state.zip.previous")):
        if candidate.exists():
            try:
                return _read_verified(candidate)
            except (ValueError, OSError, KeyError):
                pass
    raise ValueError("No verified recovery snapshot is available.")


def prepare_parallel(review, drive_root, *, folds=FOLDS, setting=NoiseSetting("combined", .01),
                     legacy_index=None, emit=print):
    """One-time, read-only handoff from a stopped serial runner into fold stores.

    Stop the old writer first. A published plan is never reseeded on reconnect.
    Partial preparation can be retried, but cannot replace a different handoff.
    """
    drive_root = Path(drive_root).resolve()
    folds = tuple(_fold(f) for f in folds)
    if not folds or len(set(folds)) != len(folds):
        raise ValueError("Select unique folds.")
    plan_file = drive_root / "parallel/plan.json"
    code = artifacts.source_fingerprint(review.root)
    all_problems, historical, bindings = _inputs(review, folds)
    inputs_fingerprint = artifacts.fingerprint({key: model.identity(review.root) for key, model in historical.items()})
    if plan_file.exists():
        plan = _verified_json(plan_file)
        if (plan["folds"] != list(folds) or plan["code_fingerprint"] != code
                or plan["training_noise"] != asdict(setting)
                or plan["original_source"] != review.source_fingerprint
                or plan["historical_inputs_fingerprint"] != inputs_fingerprint):
            raise ValueError("An existing parallel plan differs; no worker outputs were overwritten.")
        emit("Existing handoff retained; fold progress has not been reset.")
        return plan
    old_state = drive_root / "recovery/state.zip"
    has_old = old_state.exists() or old_state.with_name("state.zip.previous").exists()
    with TemporaryDirectory(prefix="qml-fold-handoff-") as temporary:
        source_root = (Path(temporary) / "original").resolve()
        source_root.mkdir()
        old_recovery = DriveRecovery(source_root, drive_root, emit=emit)
        source_index, source = None, None
        if has_old:
            old_recovery.restore(read_only=True)
            source_index = locate_index(source_root, legacy_index)
            if source_index is None:
                raise ValueError("Existing recovery has no study index; preserve it and inspect before partitioning.")
            source = artifacts.load_json(source_index)
            common = {key: source["protocol"][key] for key in COMMON}
            if common["code_fingerprint"] != code or common["training_noise"] != asdict(setting) or common["seed"] != DEFAULT_SEED:
                raise ValueError("Saved source/noise/seed differs; no checkpoints were changed.")
            _check_protocol(source["protocol"], _protocol(review, all_problems, historical, bindings, common))
        elif any((drive_root / "results/runs" / stage).exists() for stage in STAGES):
            raise ValueError("Legacy checkpoints exist without a verified recovery snapshot; no fresh start was made.")
        identity = {"version": 1, "folds": list(folds), "code_fingerprint": code,
                    "original_source": review.source_fingerprint,
                    "original_report": review.report_path.relative_to(review.root).as_posix(),
                    "training_noise": asdict(setting), "seed": DEFAULT_SEED,
                    "historical_inputs_fingerprint": inputs_fingerprint,
                    "source_state_sha256": hashlib.sha256(_state_bytes(drive_root)).hexdigest() if has_old else None,
                    "source_index": source_index.relative_to(source_root).as_posix() if source_index else None,
                    "source_index_sha256": artifacts._file_digest(source_index) if source_index else None}
        plan_id = artifacts.fingerprint(identity)[:16]
        summaries = []
        for fold in folds:
            target = drive_root / "parallel" / f"fold_{fold}"
            marker = target / "preparation.json"
            if marker.exists() and _verified_json(marker)["plan_id"] != plan_id:
                raise ValueError("A different fold handoff already exists; nothing was overwritten.")
            if (target / "handoff.json").exists():
                handoff = _verified_json(target / "handoff.json")
                if handoff["plan_id"] != plan_id:
                    raise ValueError("Fold output belongs to another handoff.")
                summaries.append(handoff["initial_coverage"])
                continue
            _json_publish(marker, {"plan_id": plan_id, "fold": fold})
            fold_review = select_review_fold(review, fold)
            problems, models, fold_bindings = _inputs(fold_review, (fold,))
            seed_root = (Path(temporary) / f"fold_{fold}").resolve()
            seed_root.mkdir()
            recovery = DriveRecovery(seed_root, target, emit=emit)
            supervised_keys = {p.original["path"].name for p in problems} | {p.reference["path"].name for p in problems}
            unlearned_keys = {f"{p.key}_{method}" for p in problems for method in ("guided", "uniform")}
            selected, partial_steps = set(), []
            if source is not None:
                for stage in STAGES:
                    for file in sorted((source_root / "results/runs" / stage).glob("*/manifest.json")):
                        manifest = artifacts.load_json(file)
                        run_identity = manifest["identity"]
                        if run_identity["config"]["data"]["fold"] != fold:
                            continue
                        _check_protocol(run_identity, common)
                        allowed = (run_identity.get("historical_problem") in supervised_keys if stage == "noisy_supervised"
                                   else f"{run_identity.get('problem')}_{run_identity.get('method')}" in unlearned_keys)
                        if not allowed:
                            raise ValueError("Unexpected model in the noisy handoff.")
                        relative = file.parent.relative_to(source_root).as_posix()
                        selected.add(relative)
                        _copy_files(file.parent, seed_root / relative)
                        if manifest["status"] == "complete":
                            artifacts.load_run(file.parent)
                            record = old_recovery.catalog["runs"].get(relative)
                            if record is None:
                                raise ValueError("Completed source model has no verified archive.")
                            content = _read_verified(_local(drive_root, record["archive"]))
                            if hashlib.sha256(content).hexdigest() != record["sha256"]:
                                raise ValueError("Completed source archive checksum changed.")
                            publish(_local(target, record["archive"]), content)
                            recovery.catalog["runs"][relative] = record
                        else:
                            recovery._register(seed_root / relative)
                            checkpoint = seed_root / relative / "checkpoints/model.resume.json"
                            if checkpoint.exists():
                                content = checkpoint.read_bytes()
                                partial_steps.append(artifacts.load_json(checkpoint)["step"])
                                _publish_checkpoint(target / relative / "checkpoints/model.resume.json", content)
                protocol = _protocol(fold_review, problems, models, fold_bindings, common)
                directory = seed_root / "results/noisy_training" / artifacts.fingerprint(protocol)[:16]
                directory.mkdir(parents=True)
                for name in ("source.zip",):
                    if (source_index.parent / name).exists():
                        _copy_files(source_index.parent / name, directory / name)
                for problem in problems:
                    teacher = source_index.parent / "teachers" / f"{problem.key}.json"
                    if teacher.exists():
                        _copy_files(teacher, directory / "teachers" / teacher.name)
                groups = {"supervised": {k: v for k, v in source["supervised"].items() if k in supervised_keys},
                          "unlearned": {k: v for k, v in source["unlearned"].items() if k in unlearned_keys}}
                if any(v["run"] not in selected for group in groups.values() for v in group.values()):
                    raise ValueError("A selected study entry has no model in recovery.")
                new_ids = {Path(relative).name for relative in selected}
                evaluations = []
                for record in source["evaluations"]:
                    eligible = models if record["regime"] == "historical" else new_ids
                    if record["run_id"] not in eligible:
                        continue
                    file = _local(source_root, record["file"])
                    if artifacts._file_digest(file) != record["sha256"]:
                        raise ValueError("Saved deployment prediction changed during handoff.")
                    destination = directory / "evaluation" / file.name
                    _copy_files(file, destination)
                    _copy_files(file.with_suffix(".json"), destination.with_suffix(".json"))
                    evaluations.append({**record, "file": destination.relative_to(seed_root).as_posix()})
                performance = source.get("performance_directory")
                if performance:
                    _copy_files(_local(source_root, performance), _local(seed_root, performance))
                artifacts.save_json(directory / "study.json", {
                    "protocol": protocol, "complete": False, **groups, "evaluations": evaluations,
                    "performance_directory": performance, "previous_executions": [],
                    "handoff": {"plan_id": plan_id, "source_index": identity["source_index"],
                                "source_index_sha256": identity["source_index_sha256"],
                                "note": "Partitioned saved artifacts; no model was fitted or relabelled."}})
                _copy_files(source_index, seed_root / "results/noisy_training/handoff/source_study.json")
            initial = {"fold": fold, "planned": len(noisy_training.training_plan(problems)),
                       "completed": len(recovery.catalog["runs"]), "partial_with_updates": len(partial_steps),
                       "saved_partial_updates": sum(partial_steps)}
            artifacts.save_json(seed_root / "results/noisy_training/handoff/provenance.json", {
                **identity, "fold": fold, "plan_id": plan_id,
                "fold_inputs_fingerprint": artifacts.fingerprint({key: model.identity(review.root) for key, model in models.items()})})
            recovery.snapshot()
            _json_publish(target / "handoff.json", {"plan_id": plan_id, "fold": fold, "code_fingerprint": code,
                          "initial_coverage": initial,
                          "compatible_benchmark_problems": sorted(supervised_keys | {
                              p.original["path"].name for p in all_problems})})
            summaries.append(initial)
            emit(f"Fold {fold} ready: {initial['completed']} completed fits, {len(partial_steps)} saved optimizer states.")
        plan = {**identity, "plan_id": plan_id, "ready": True, "initial_coverage": summaries,
                "execution": "One independent runtime per fold; multiple independent model workers inside each runtime.",
                "legacy_policy": "Original recovery remains untouched. Do not run the old serial writer alongside these runners."}
        _json_publish(plan_file, plan)
        return plan


def fold_recovery(runtime_root, drive_root, fold, *, emit=print, namespace="parallel"):
    fold = _fold(fold)
    drive_root = Path(drive_root).resolve()
    if namespace not in ("parallel", "parallel_cpu"):
        raise ValueError("Unknown fold storage namespace.")
    plan = _verified_json(drive_root / namespace / "plan.json")
    if not plan["ready"] or fold not in plan["folds"]:
        raise ValueError("This fold is not assigned by the prepared parallel plan.")
    handoff = _verified_json(drive_root / namespace / f"fold_{fold}" / "handoff.json")
    if (not plan["ready"] or fold not in plan["folds"] or handoff["fold"] != fold
            or handoff["plan_id"] != plan["plan_id"]
            or handoff["code_fingerprint"] != artifacts.source_fingerprint(runtime_root)):
        raise ValueError("Fold handoff/source does not match. No fitting was started.")
    recovery = DriveRecovery(runtime_root, drive_root / namespace / f"fold_{fold}", emit=emit)
    recovery.restore()
    for stage in STAGES:
        for file in (Path(runtime_root) / "results/runs" / stage).glob("*/manifest.json"):
            if artifacts.load_json(file)["identity"]["config"]["data"]["fold"] != fold:
                raise ValueError("Another fold's models are present in this runtime; use a separate runtime.")
    return recovery


def prepare_fold_execution(review, problems, historical, bindings, setting, *, selected_index=None,
                           require_gpu_device=True, worker_counts=(5, 8)):
    folds = {p.fold for p in problems}
    if len(folds) != 1:
        raise ValueError("A fold runner must select exactly one fold.")
    # The one-time handoff saved the actual source benchmark identity. Reuse it
    # only after prepare_execution verifies source, environment, noise and the
    # pinned execution. Its timings are not relabelled as measurements here.
    handoff = artifacts.load_json(review.root / "results/noisy_training/handoff/provenance.json")
    inputs_fingerprint = artifacts.fingerprint({key: model.identity(review.root) for key, model in historical.items()})
    if handoff["fold"] != next(iter(folds)) or inputs_fingerprint != handoff["fold_inputs_fingerprint"]:
        raise ValueError("The fold's saved input membership/configuration differs from its handoff.")
    source = review.root / "results/noisy_training/handoff/source_study.json"
    compatible = ()
    if source.exists():
        original = artifacts.load_json(source)
        compatible = tuple(row["historical_problem"] for row in original["protocol"]["plan"]
                           if row["stage"] == "noisy_supervised")
        if original["protocol"]["code_fingerprint"] != artifacts.source_fingerprint(review.root):
            raise ValueError("The source benchmark belongs to different scientific code.")
    return prepare_execution(review, problems, historical, bindings, setting, selected_index=selected_index,
        require_gpu_device=require_gpu_device, worker_counts=worker_counts, compatible_benchmark_problems=compatible)


def collect_parallel(review, drive_root, *, folds=FOLDS, require_complete=True, setting=NoiseSetting("combined", .01),
                     emit=print, namespace="parallel", imported_run_validator=None):
    """Read saved fold outputs only; combine numeric artifacts without prediction."""
    drive_root = Path(drive_root).resolve()
    if namespace not in ("parallel", "parallel_cpu"):
        raise ValueError("Unknown fold storage namespace.")
    plan = _verified_json(drive_root / namespace / "plan.json")
    folds = tuple(_fold(f) for f in folds)
    if plan["folds"] != list(folds) or plan["code_fingerprint"] != artifacts.source_fingerprint(review.root):
        raise ValueError("The requested fold plan/source differs.")
    problems, historical, bindings = _inputs(review, folds)
    expected_base = {"code_fingerprint": plan["code_fingerprint"], "training_noise": asdict(setting), "seed": DEFAULT_SEED}
    merged = {"supervised": {}, "unlearned": {}, "evaluations": []}
    sources, environments, executions, missing = {}, {}, {}, []
    with TemporaryDirectory(prefix="qml-parallel-review-") as temporary:
        incoming = []
        for fold in folds:
            target = drive_root / namespace / f"fold_{fold}"
            root = (Path(temporary) / f"fold_{fold}").resolve()
            root.mkdir()
            recovery = DriveRecovery(root, target, emit=emit)
            recovery.restore(read_only=True)
            index_file = locate_index(root)
            if index_file is None:
                missing.append(fold)
                continue
            index = artifacts.load_json(index_file)
            selected = select_review_fold(review, fold)
            fold_problems, fold_models, fold_bindings = _inputs(selected, (fold,))
            common = {key: index["protocol"][key] for key in COMMON}
            _check_protocol(common, expected_base)
            _check_protocol(index["protocol"], _protocol(selected, fold_problems, fold_models, fold_bindings, common))
            expected_keys = {
                "supervised": {p.original["path"].name for p in fold_problems} | {p.reference["path"].name for p in fold_problems},
                "unlearned": {f"{p.key}_{method}" for p in fold_problems for method in ("guided", "uniform")}}
            for group, keys in expected_keys.items():
                if not set(index[group]).issubset(keys) or (index["complete"] and set(index[group]) != keys):
                    raise ValueError("Missing or foreign model entries in fold " + str(fold))
            if require_complete and (not index["complete"] or len(index["supervised"]) + len(index["unlearned"]) != len(index["protocol"]["plan"])):
                raise ValueError(f"Fold {fold} is incomplete. Finish its runner or explicitly request a partial review.")
            incoming.append((fold, root, target, index_file, index))
        if require_complete and missing:
            raise ValueError(f"Missing completed fold outputs: {missing}. No aggregate was declared complete.")
        for fold, root, target, file, index in incoming:
            copied = set()
            for group in ("supervised", "unlearned"):
                for key, record in index[group].items():
                    run = artifacts.load_run(_local(root, record["run"]))
                    if run["config"]["data"]["fold"] != fold:
                        raise ValueError("A fold index links another fold's model.")
                    if imported_run_validator is None or not imported_run_validator(root, run, index):
                        _check_protocol(run["manifest"]["identity"], {k: index["protocol"][k] for k in COMMON})
                    if key in merged[group]:
                        raise ValueError("Duplicate model assignment across fold runners.")
                    merged[group][key] = record
                    if record["run"] not in copied:
                        _copy_files(run["path"], _local(review.root, record["run"]))
                        copied.add(record["run"])
            for record in index["evaluations"]:
                prediction = _local(root, record["file"])
                if artifacts._file_digest(prediction) != record["sha256"]:
                    raise ValueError("A saved deployment prediction checksum changed.")
                _copy_files(prediction, _local(review.root, record["file"]))
                _copy_files(prediction.with_suffix(".json"), _local(review.root, record["file"]).with_suffix(".json"))
                merged["evaluations"].append(record)
            if index.get("performance_directory"):
                relative = index["performance_directory"]
                _copy_files(_local(root, relative), _local(review.root, relative))
            audit = review.root / "results/noisy_training/parallel_sources" / plan["plan_id"] / f"fold_{fold}" / artifacts._file_digest(file)[:16]
            _copy_files(file, audit / "source_study.json")
            _copy_files(file.parent, audit / "study")
            for directory in ("transport", "runtime_support", "handoff"):
                _copy_files(root / "results/noisy_training" / directory, audit / directory)
            sources[str(fold)] = {"drive_folder": str(target), "index": file.relative_to(root).as_posix(),
                                 "sha256": artifacts._file_digest(file), "complete": index["complete"],
                                 "audit": audit.relative_to(review.root).as_posix()}
            environments[str(fold)] = index["protocol"]["environment"]
            executions[str(fold)] = index["protocol"]["execution"]
    # Preserve every fold's true environment/execution. This index is a review
    # aggregate, never an identity used to continue an optimizer.
    common = {**expected_base, "environment": {"per_fold": environments}, "execution": {"per_fold": executions}}
    protocol = _protocol(review, problems, historical, bindings, common)
    directory = review.root / "results/noisy_training" / ("parallel_" + artifacts.fingerprint(sources)[:16])
    output = directory / "study.json"
    complete = not missing and all(s["complete"] for s in sources.values())
    artifacts.save_json(output, {"protocol": protocol, **merged, "complete": complete,
        "kind": "parallel_saved_review", "optimizer_continuation_allowed": False,
        "source_folds": sources, "missing_folds": missing, "parallel_plan_id": plan["plan_id"]})
    # The normal saved analysis checks exact IDs, prediction hashes, matched
    # references and role coverage; it never invokes a quantum executor.
    from src.evaluation.noisy_training_analysis import noisy_training_tables
    index, tables = noisy_training_tables(output, review.root)
    if require_complete and not tables["coverage"].completed.all():
        raise ValueError("A supposedly complete fold export has missing matched evaluations.")
    if index["complete"] and not tables["coverage"].completed.all():
        index["complete"] = False
        artifacts.save_json(output, index)
    return output, tables
