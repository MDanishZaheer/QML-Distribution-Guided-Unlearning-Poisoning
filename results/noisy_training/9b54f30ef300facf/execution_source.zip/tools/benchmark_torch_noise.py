"""Validate and time a PyTorch noisy prototype on SYNTHETIC inputs only.

Run with the QML interpreter. --torch-python can select a separate existing
PyTorch environment. No packages are installed and no research artifacts are
loaded, predicted, trained, resumed or changed.
"""

from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, replace
from pathlib import Path
from tempfile import TemporaryDirectory
from time import perf_counter
import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys

import numpy as np
from qiskit import transpile
from qiskit_aer import AerSimulator

from src.config import BackendConfig, CircuitConfig, DEFAULT_SEED, TrainingConfig
from src.models.circuits import build_malik_circuit, parameter_groups
from src.models.noise import NoiseSetting, build_gate_noise
from src.models.noisy_training import NoisyBatchService
from src.models.parallel_aer import AerExecution
from src.training import optimize
from src.unlearning.methods import unlearning_loss_and_gradient


def schedule(config):
    circuit = build_malik_circuit(config)
    inputs, weights = parameter_groups(circuit)
    result = []
    for instruction in circuit.data:
        gate = instruction.operation
        item = {"gate": gate.name, "qubits": [circuit.find_bit(q).index for q in instruction.qubits]}
        if gate.name != "cx":
            expression = gate.params[0]
            if expression in weights:
                angle = {"kind": "weight", "index": weights.index(expression)}
            else:
                indices = [i for i, p in enumerate(inputs) if p in expression.parameters]
                expected = inputs[indices[0]]
                for i in indices[1:]:
                    expected = expected * inputs[i]
                if expression != expected:
                    raise ValueError("Prototype cannot represent this input expression.")
                angle = {"kind": "input", "indices": indices}
            item["angle"] = angle
        result.append(item)
    return result


def save_report(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def prepare_cases(output, *, repeats=3, model_counts=(1, 5)):
    rng = np.random.default_rng(DEFAULT_SEED)
    cases = []
    config = CircuitConfig()
    def add(name, noise, *, models=1, batch=2, objective="supervised", timed=False,
            initialization=False, alpha=1., regularization=.01, trajectory=0, scale=1., uniform=False):
        features = rng.uniform(0, np.pi, (models, batch, 4))
        if batch >= 2:
            features[0, 0] = 0
            features[0, 1] = np.pi
        weights = rng.normal(0, .1, (models, 72)) if initialization else rng.uniform(-2.5, 2.5, (models, 72))
        targets = np.eye(3)[rng.integers(0, 3, (models, batch))]
        arrays = {"features": features, "weights": weights, "targets": targets}
        if objective == "unlearning":
            arrays.update(anchor_features=rng.uniform(0, np.pi, (models, batch, 4)),
                anchor_targets=rng.dirichlet([1., 1., 1.], (models, batch)),
                original_weights=weights + rng.normal(0, .03, weights.shape))
            # One fixed forget target per independent model, zero forgotten mass.
            retained = rng.dirichlet([1., 1.], models)
            if uniform:
                retained[:] = .5
            q = np.concatenate([retained, np.zeros((models, 1))], axis=1)
            arrays["targets"] = np.broadcast_to(q[:, None, :], (models, batch, 3)).copy()
        if trajectory:
            arrays["batch_indices"] = np.asarray([rng.choice(batch, 10, replace=False) for _ in range(trajectory)])
            if objective == "unlearning":
                arrays["anchor_indices"] = np.asarray([rng.choice(batch, 10, replace=False) for _ in range(trajectory)])
        if models == 1:
            arrays = {key: value[0] if key not in ("batch_indices", "anchor_indices") else value for key, value in arrays.items()}
        filename = name + ".npz"
        np.savez_compressed(output / filename, **arrays)
        case = {"name": name, "file": filename, "noise": noise, "models": models,
                "objective": objective, "repeats": repeats if timed else 0,
                "alpha": alpha, "regularization": regularization, "trajectory_steps": trajectory,
                "check_density": not timed, "logit_scale": scale}
        cases.append(case)
    profile = {"one_qubit_strength": .01, "two_qubit_strength": .02, "readout_flip": .01}
    add("ideal_extremes", {k: 0. for k in profile})
    add("combined_initialization", profile, initialization=True)
    add("combined_rotated_weights", profile, scale=1.3)
    add("gate_only", {**profile, "readout_flip": 0.})
    add("readout_only", {**{k: 0. for k in profile}, "readout_flip": .01})
    add("stronger_combined", {"one_qubit_strength": .02, "two_qubit_strength": .04, "readout_flip": .02})
    add("unlearning_default", profile, objective="unlearning")
    add("unlearning_without_anchors", profile, objective="unlearning", alpha=0., regularization=0.)
    add("independent_models", profile, models=2)
    add("adam_trajectory", profile, batch=12, initialization=True, trajectory=3)
    add("uniform_unlearning", profile, objective="unlearning", uniform=True)
    add("unlearning_adam_trajectory", profile, batch=12, objective="unlearning", trajectory=3)
    for models in model_counts:
        add(f"supervised_m{models}_b10", profile, models=models, batch=10, timed=True, initialization=True)
        add(f"unlearning_m{models}_b10", profile, models=models, batch=10, objective="unlearning", timed=True)
    manifest = {"seed": DEFAULT_SEED, "synthetic_only": True, "n_parameters": 72,
                "operations": schedule(config), "cases": cases}
    path = output / "cases.json"
    save_report(path, manifest)
    return path, manifest


def _aligned(arrays, models):
    return {k: v[None] if models == 1 and k not in ("batch_indices", "anchor_indices") else v for k, v in arrays.items()}


def aer_reference(manifest, output, *, threads=2, device="CPU"):
    directory = output / "aer"
    directory.mkdir(exist_ok=True)
    records = []
    for case in manifest["cases"]:
        print("Aer reference:", case["name"], flush=True)
        with np.load(output / case["file"], allow_pickle=False) as saved:
            arrays = {k: saved[k] for k in saved.files}
        a = _aligned(arrays, case["models"])
        noise = case["noise"]
        level, readout = noise["one_qubit_strength"], noise["readout_flip"]
        if level and readout:
            setting = NoiseSetting("combined", level)
        elif level:
            setting = NoiseSetting("depolarizing", level)
        elif readout:
            setting = NoiseSetting("readout", readout)
        else:
            setting = NoiseSetting()
        assert setting.describe()["two_qubit_strength"] == noise["two_qubit_strength"]
        execution = AerExecution(device=device, workers=case["models"], threads=threads,
            circuit_batch_size=2048, memory_mb=4096, runtime_binding=False, gpu_parameter_batching=False)
        circuit_config = CircuitConfig(logit_scale=case["logit_scale"])
        with NoisyBatchService(circuit_config, BackendConfig(shots=None), execution, setting) as service:
            models = [service.model(DEFAULT_SEED + i) for i in range(case["models"])]
            def call_one(i):
                if case["objective"] == "unlearning":
                    return unlearning_loss_and_gradient(models[i], a["features"][i], a["anchor_features"][i],
                        a["targets"][i], a["anchor_targets"][i], a["weights"][i], a["original_weights"][i],
                        case["alpha"], case["regularization"])
                return models[i].loss_and_gradient(a["features"][i], a["targets"][i], a["weights"][i])
            def call():
                with ThreadPoolExecutor(max_workers=case["models"]) as pool:
                    result = list(pool.map(call_one, range(case["models"])))
                return np.asarray([r[0] for r in result]), np.asarray([r[1] for r in result])
            loss, gradient = call()
            probabilities = np.stack([models[i].predict_proba(a["features"][i], a["weights"][i])
                                      for i in range(case["models"])])
            result = {"loss": loss, "gradient": gradient, "probabilities": probabilities}
            if case["models"] == 1:
                result = {k: v[0] for k, v in result.items()}
            if case["check_density"]:
                circuit = build_malik_circuit(circuit_config)
                xp, wp = parameter_groups(circuit)
                bound = circuit.assign_parameters({**dict(zip(xp, a["features"][0, 0])), **dict(zip(wp, a["weights"][0]))})
                bound.save_density_matrix(label="rho")
                backend = AerSimulator(method="density_matrix", device=device, precision="double",
                    basis_gates=["ry", "rz", "cx"], noise_model=build_gate_noise(setting), max_parallel_threads=threads)
                result["first_density"] = np.asarray(backend.run(transpile(bound, backend, optimization_level=0), shots=1).result().data()["rho"])
            if case["name"] == "combined_rotated_weights":
                indices = np.asarray([0, 1, 17, 35, 36, 65, 70, 71])
                finite = []
                for index in indices:
                    delta = np.zeros(72)
                    delta[index] = 1e-6
                    finite.append((models[0].loss(arrays["features"], arrays["targets"], arrays["weights"] + delta)
                        - models[0].loss(arrays["features"], arrays["targets"], arrays["weights"] - delta)) / 2e-6)
                result["finite_difference_indices"] = indices
                result["finite_difference_gradient"] = np.asarray(finite)
            if case["trajectory_steps"]:
                counter = [0]
                with TemporaryDirectory(prefix="qml-synthetic-adam-") as temporary:
                    checkpoint = Path(temporary) / "state.json"
                    states = []
                    def objective(weights):
                        indices = arrays["batch_indices"][counter[0]]
                        step = counter[0]
                        counter[0] += 1
                        if case["objective"] == "unlearning":
                            anchors = arrays["anchor_indices"][step]
                            return unlearning_loss_and_gradient(models[0], arrays["features"][indices],
                                arrays["anchor_features"][anchors], arrays["targets"][indices], arrays["anchor_targets"][anchors],
                                weights, arrays["original_weights"], case["alpha"], case["regularization"])
                        return models[0].loss_and_gradient(arrays["features"][indices], arrays["targets"][indices], weights)
                    def evaluate(weights):
                        if case["objective"] == "unlearning":
                            value = models[0].loss(arrays["features"], arrays["targets"], weights)
                            value += case["alpha"] * models[0].loss(arrays["anchor_features"], arrays["anchor_targets"], weights)
                            value += case["regularization"] * np.sum((weights - arrays["original_weights"])**2)
                            return {"objective": value}
                        return {"validation_loss": models[0].loss(arrays["features"], arrays["targets"], weights)}
                    def capture(row):
                        state = json.loads(checkpoint.read_text())
                        states.append({k: state[k] for k in ("step", "weights", "first_moment", "second_moment")})
                    config = TrainingConfig(steps=case["trajectory_steps"], batch_size=10, evaluate_every=1)
                    optimize(arrays["weights"], objective, evaluate, config,
                             "objective" if case["objective"] == "unlearning" else "validation_loss",
                             callback=capture, checkpoint_path=checkpoint)
                    for key in ("weights", "first_moment", "second_moment"):
                        result["trajectory_" + key] = np.asarray([s[key] for s in states])
            np.savez_compressed(directory / (case["name"] + ".npz"), **result)
            seconds = []
            for _ in range(case["repeats"]):
                start = perf_counter()
                call()
                seconds.append(perf_counter() - start)
            records.append({"name": case["name"], "models": case["models"], "device": device,
                "execution": asdict(execution), "seconds": seconds,
                "median_seconds": float(np.median(seconds)) if seconds else None})
            save_report(directory / "reference_report.json", records)
    return records


def compare(manifest, output, worker_reports):
    checks, timings = [], []
    failures = []
    for device, worker in worker_reports.items():
        report = json.loads((worker / "worker_report.json").read_text())
        if (report["device"] != device or [r["name"] for r in report["cases"]] != [r["name"] for r in manifest["cases"]]):
            raise AssertionError("A worker omitted or reordered required validation cases.")
        source = output / "source/tools/torch_density_probe.py"
        if report["helper_sha256"] != hashlib.sha256(source.read_bytes()).hexdigest():
            raise AssertionError("The worker used different prototype source bytes.")
        reference_times = {r["name"]: r for r in json.loads((output / "aer/reference_report.json").read_text())}
        for case, measured in zip(manifest["cases"], report["cases"]):
            expected = np.load(output / "aer" / (case["name"] + ".npz"), allow_pickle=False)
            actual = np.load(worker / (case["name"] + ".npz"), allow_pickle=False)
            row = {"device": device, "case": case["name"]}
            for key, tolerance in (("probabilities", 1e-10), ("loss", 1e-10), ("gradient", 1e-9)):
                row[key + "_max_error"] = float(np.max(np.abs(expected[key] - actual[key])))
                if (expected[key].shape != actual[key].shape or not np.isfinite(actual[key]).all()
                        or not np.isfinite(expected[key]).all() or row[key + "_max_error"] > tolerance):
                    failures.append(device + ":" + case["name"] + ":" + key)
            if case["check_density"]:
                density = actual["density"]
                first = density[0] if density.ndim == 3 else density[0, 0]
                row["density_max_error"] = float(np.max(np.abs(first - expected["first_density"])))
                row["trace_error"] = float(np.max(np.abs(np.trace(density, axis1=-2, axis2=-1) - 1)))
                row["hermiticity_error"] = float(np.max(np.abs(density - density.swapaxes(-1, -2).conj())))
                row["minimum_eigenvalue"] = float(np.linalg.eigvalsh(density).min())
                if max(row["density_max_error"], row["trace_error"], row["hermiticity_error"]) > 1e-10 or row["minimum_eigenvalue"] < -1e-10:
                    failures.append(device + ":" + case["name"] + ":density")
            if case["trajectory_steps"]:
                for key in ("weights", "first_moment", "second_moment"):
                    error = float(np.max(np.abs(expected["trajectory_" + key] - actual["trajectory_" + key])))
                    row["trajectory_" + key + "_max_error"] = error
                    if error > 1e-9:
                        failures.append(device + ":trajectory:" + key)
            if "finite_difference_gradient" in expected.files:
                row["finite_difference_max_error"] = float(np.max(np.abs(
                    actual["gradient"][expected["finite_difference_indices"]] - expected["finite_difference_gradient"])))
                if not np.isfinite(row["finite_difference_max_error"]) or row["finite_difference_max_error"] > 1e-8:
                    failures.append(device + ":finite_difference")
            checks.append(row)
            if measured["median_seconds"] is not None:
                baseline = reference_times[case["name"]]
                timings.append({"device": device, "case": case["name"], "models": measured["models"],
                    "aer_device": baseline["device"], "aer_seconds": baseline["median_seconds"],
                    "torch_seconds": measured["median_seconds"],
                    "speedup": baseline["median_seconds"] / measured["median_seconds"],
                    "torch_gradient_evaluations_per_second": measured["models"] / measured["median_seconds"],
                    "peak_allocated_bytes": measured.get("peak_allocated_bytes")})
    return checks, timings, failures


def run(output, *, torch_python=sys.executable, devices=("cpu", "cuda"), threads=2,
        repeats=3, model_counts=(1, 5), aer_device="CPU"):
    output = Path(output).resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError("Use a fresh output directory; benchmark evidence is not overwritten.")
    output.mkdir(parents=True, exist_ok=True)
    source_files = ("tools/benchmark_torch_noise.py", "tools/torch_density_probe.py",
                    "src/models/circuits.py", "src/models/noisy_training.py", "src/models/noise.py",
                    "src/models/vqc.py", "src/unlearning/methods.py", "src/training.py")
    project = Path(__file__).resolve().parents[1]
    for relative in source_files:
        target = output / "source" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(project / relative, target)
    manifest_file, manifest = prepare_cases(output, repeats=repeats, model_counts=model_counts)
    import qiskit, qiskit_aer
    report = {"synthetic_only": True, "research_results": False, "seed": DEFAULT_SEED,
        "aer_python": sys.executable, "torch_python": str(torch_python), "platform": platform.platform(),
        "numpy": np.__version__, "qiskit": qiskit.__version__, "qiskit_aer": qiskit_aer.__version__,
        "aer_available_devices": list(AerSimulator().available_devices()), "threads": threads,
        "aer_device": aer_device, "dtype": "complex128/float64", "status": "running",
        "timing_scope": "Loss/gradient calls including device transfers; excludes Adam arithmetic, full training/validation evaluation and checkpoint/storage overhead.",
        "scope": "Exact density-matrix synthetic predictions, losses, all 72 gradients, independent model batches, and short Adam trajectories. No production checkpoint compatibility is inferred.",
        "helper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "manifest_sha256": hashlib.sha256(manifest_file.read_bytes()).hexdigest()}
    save_report(output / "report.json", report)
    worker_reports = {}
    helper = Path(__file__).with_name("torch_density_probe.py")
    for device in devices:
        directory = output / ("torch_" + device)
        command = [str(torch_python), "-X", "utf8", "-B", str(helper), str(manifest_file), str(directory),
                   "--device", device, "--threads", str(threads)]
        # Only synthetic serialized arrays cross interpreters. No installation,
        # package-path mixing, model import, or checkpoint migration occurs.
        subprocess.run(command, check=True)
        worker_reports[device] = directory
    aer_reference(manifest, output, threads=threads, device=aer_device)
    checks, timings, failures = compare(manifest, output, worker_reports)
    report.update(status="failed" if failures else "passed", checks=checks, timings=timings,
        failures=failures,
        torch_workers={k: json.loads((p / "worker_report.json").read_text()) for k, p in worker_reports.items()})
    report["minimum_speedup_for_provisional_adoption"] = 2.0
    report["provisional_candidates"] = [device for device in devices if not failures
        and len([r for r in timings if r["device"] == device and r["models"] == 5]) == 2
        and min(r["speedup"] for r in timings if r["device"] == device and r["models"] == 5) >= 2.0]
    save_report(output / "report.json", report)
    for row in timings:
        print(f"{row['device']} {row['case']}: {row['speedup']:.2f}x versus Aer {row['aer_device']}; "
              f"{row['torch_gradient_evaluations_per_second']:.2f} model gradients/s", flush=True)
    print("VALIDATION:", report["status"], "| report:", output / "report.json", flush=True)
    if failures:
        raise AssertionError("PyTorch prototype failed validation: " + ", ".join(failures))
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True)
    parser.add_argument("--torch-python", default=sys.executable)
    parser.add_argument("--devices", nargs="+", choices=("cpu", "cuda"), default=["cpu", "cuda"])
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--model-counts", nargs="+", type=int, default=[1, 5])
    parser.add_argument("--aer-device", choices=("CPU", "GPU"), default="CPU")
    args = parser.parse_args()
    run(args.output, torch_python=args.torch_python, devices=args.devices, threads=args.threads,
        repeats=args.repeats, model_counts=args.model_counts, aer_device=args.aer_device)
