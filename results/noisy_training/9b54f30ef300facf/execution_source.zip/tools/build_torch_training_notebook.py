"""Generate the one-T4, all-five-fold entry point without executing any cells."""

from pathlib import Path
import json
import textwrap


def build():
    root = Path(__file__).resolve().parents[1]
    cells = []
    def md(text):
        cells.append({"cell_type": "markdown", "metadata": {},
            "source": textwrap.dedent(text).strip().splitlines(keepends=True)})
    def code(text):
        cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [],
            "source": (textwrap.dedent(text).strip() + "\n").splitlines(keepends=True)})

    md("""
    # Noisy training and unlearning on one GPU

    Upload the complete `collab` folder directly inside `MyDrive`, choose a
    T4 GPU runtime (16 GiB), and Run all here. This is the only training notebook
    needed: independent optimizers from all five folds share actual PyTorch
    CUDA tensor batches. Do not open the separate fold notebooks for this run.

    The exact six-qubit noisy circuit, loss and NumPy Adam stay the same.
    Double-precision automatic differentiation replaces parameter-shift circuit
    expansion. The new backend and actual hardware/software are recorded.
    This notebook has not been executed to create research results locally.
    """)
    md("""
    ## 1. Connect Drive

    Keep any existing `recovery/` and fold stores when uploading updated code.
    Stop old writers first. The new run uses `collab/torch/` for durable recovery.
    """)
    code("""
    from pathlib import Path
    import sys
    from google.colab import drive

    DRIVE_FOLDER = "collab"
    drive.mount("/content/drive")
    UPLOAD_ROOT = Path("/content/drive/MyDrive") / DRIVE_FOLDER
    if not (UPLOAD_ROOT / "input_manifest.json").is_file():
        raise FileNotFoundError(f"Upload the complete folder to {UPLOAD_ROOT}")
    sys.path.insert(0, str(UPLOAD_ROOT))
    print("Upload folder:", UPLOAD_ROOT)
    """)
    md("""
    ### 1.1 Check dependencies

    Aer CPU supplies an independent numerical check; PyTorch supplies CUDA
    training. Colab's installed PyTorch is checked and recorded without an
    automatic upgrade. If installation requests a session restart, restart and
    Run all again. Keep versions fixed while an optimizer is unfinished.
    """)
    code("""
    from tools.colab_bootstrap import install_dependencies

    install_dependencies(UPLOAD_ROOT, device="CPU")
    """)
    md("""
    ## 2. Stage saved inputs locally

    Verify the supplied archive and load its exact numeric PCA features,
    memberships, labels and original results. There is no MNIST download, PCA
    refit, noiseless retraining or repeated parameter-ablation study.
    """)
    code("""
    from tools.colab_bootstrap import stage_runtime
    import os

    PROJECT_ROOT, input_manifest = stage_runtime(
        UPLOAD_ROOT, runtime_parent="/content/qml_torch_noisy"
    )
    sys.path.insert(0, str(PROJECT_ROOT))
    os.chdir(PROJECT_ROOT)
    print("Runtime-local project:", PROJECT_ROOT)
    """)
    md("""
    ### 2.1 Verify PyTorch can use this GPU

    One persistent CUDA process handles all model requests. The notebook's
    NumPy optimizers each keep separate weights, Adam moments and random streams.
    A missing CUDA device stops before fitting. GPU memory occupancy is measured,
    but throughput determines concurrency.
    """)
    code("""
    import pandas as pd
    import matplotlib.pyplot as plt
    from IPython.display import display
    from tools.torch_noisy_service import TorchProcess

    torch_process = TorchProcess(device="GPU")
    display(pd.Series(torch_process.runtime, name="Actual CUDA runtime"))
    """)
    md("""
    ## 3. Set execution controls

    Keep all five folds and both attacks at the primary poisoning rates. Twenty
    optimizer workers is a fresh-run candidate, rather than twenty CUDA contexts.
    The short check below chooses among 5/10/20 workers. It does not change
    batch size 10 or the 300/100 optimization budgets.
    """)
    code("""
    from src.config import DEFAULT_SEED
    from src.models.noise import NoiseSetting
    from tools.noisy_workflow import PRIMARY_RATES

    SEED = DEFAULT_SEED  # 6304
    STUDY_FOLDS = (0, 1, 2, 3, 4)
    RUN_NOISY_TRAINING = True
    FORCE_RETRAIN = False
    NOISY_TRAINING_INDEX = None
    SHOW_ANALYSIS = True
    EXPORT_RESULTS = True
    WORKER_CANDIDATES = (5, 10, 20)
    IMPORT_SOURCE = "auto"  # Latest CPU-fold plan, GPU-fold plan, or serial recovery.
    RESTART_UNFINISHED_AER = True  # Different engine: preserve old partials; fit replacements.
    training_noise = NoiseSetting("combined", 0.01)
    print("Seed:", SEED, "| folds:", STUDY_FOLDS, "| rates:", PRIMARY_RATES)
    """)
    md("""
    ### 3.1 Distinguish poisoning from circuit noise

    Label flips and full-vector feature randomization reuse the exact archived
    training records. Quantum noise is separate: depolarizing strength .01 after
    RY/RZ, joint two-qubit depolarizing strength .02 after CX, and readout flips
    .01. Exact density evolution integrates these channels; training has no shot
    sampling. This is synthetic noise, not a calibrated hardware model.
    """)
    code("""
    display(pd.Series(training_noise.describe(), name="Training channel"))
    """)
    md("""
    ## 4. Load the completed noiseless study
    """)
    code("""
    from src.fresh_study import FreshStudy

    saved_study = FreshStudy(
        PROJECT_ROOT, PROJECT_ROOT / input_manifest["study_index"],
        progress=lambda message: print(message, flush=True),
    )
    primary_study = saved_study.select_rates(PRIMARY_RATES)
    print("Selected condition/fold pairs:", len(primary_study.conditions))
    """)
    md("""
    ### 4.1 Display the circuit
    """)
    code("""
    from src.models.circuits import build_malik_circuit
    from src.config import CircuitConfig

    first_condition = next(iter(primary_study.conditions.values()))
    circuit = build_malik_circuit(CircuitConfig(**first_condition["config"]["circuit"]))
    figure = circuit.draw(output="mpl", fold=70)
    display(figure)
    plt.close(figure)
    """)
    md("""
    ## 5. Validate the complete 230-fit plan

    All five folds cover clean and both attacks at 5/10/20/30/40/50%. Shared
    retained-data references are reused: 100 supervised and 130 unlearning fits.
    The 25% noiseless support conditions remain outside this noisy protocol.
    """)
    code("""
    from src.noisy_training import load_training_problems
    from tools.noisy_workflow import validate_plan

    noisy_problems, historical_inputs, noisy_bindings = load_training_problems(
        primary_study, STUDY_FOLDS, "all"
    )
    fit_plan = validate_plan(noisy_problems, noisy_bindings, STUDY_FOLDS)
    display(fit_plan.groupby(["fold", "stage"]).size().unstack(fill_value=0))
    print("Planned noisy fits, including reusable completed imports:", len(fit_plan))
    """)
    md("""
    ### 5.1 Confirm rate and fold coverage
    """)
    code("""
    display(noisy_bindings[["condition", "attack", "poison_rate", "fold"]]
            .drop_duplicates().groupby(["condition", "attack", "poison_rate"])
            .size().rename("planned_folds").to_frame())
    """)
    md("""
    ## 6. Reuse completed models and recover PyTorch checkpoints

    First setup reads stopped old recovery stores without modifying them.
    Completed models require full manifests, provenance and checksum-verified
    artifacts. An optimizer-only download cannot substitute for those records.
    Imported models keep their actual Aer/device provenance. Partial Aer states
    remain at their source; replacements initialize normally under PyTorch.

    On later sessions the separate PyTorch recovery store restores its own full
    Adam/RNG state. A changed engine, code, device or package identity stops
    optimizer continuation. Keep FORCE_RETRAIN False.
    """)
    code("""
    from tools.torch_noisy_workflow import prepare_torch_handoff
    from tools.noisy_drive import DriveRecovery

    handoff = prepare_torch_handoff(
        primary_study, UPLOAD_ROOT, folds=STUDY_FOLDS, setting=training_noise,
        source=IMPORT_SOURCE, restart_unfinished=RESTART_UNFINISHED_AER,
    )
    TORCH_DRIVE_ROOT = UPLOAD_ROOT / "torch"
    recovery = DriveRecovery(PROJECT_ROOT, TORCH_DRIVE_ROOT)
    recovery.restore()
    display(pd.Series(handoff, name="Recovery plan"))
    """)
    md("""
    ### 6.1 Verify durable storage

    Atomic local state is committed after every complete update. Drive backups
    run every five seconds and flush on normal interruption; abrupt VM loss can
    lose updates since the last verified backup. Completed model archives are
    verified on Drive before being reported finished.
    """)
    code("""
    from src.checkpoint_storage import verify_checkpoint_storage

    display(pd.Series(verify_checkpoint_storage(TORCH_DRIVE_ROOT), name="Storage check"))
    """)
    md("""
    ## 7. Check correctness and select model batching

    This short synthetic check compares PyTorch probabilities, loss and all
    gradients with Aer CPU. It checks independent simultaneous model gradients
    and times 5/10/20 workers on the allocated GPU. It selects measured throughput
    while retaining double precision and bounded prediction chunks. A memory
    shortage splits independent model groups without changing any optimizer's
    batch or update. The selected execution and runtime are pinned for resume.
    """)
    code("""
    from tools.torch_noisy_workflow import prepare_torch_execution

    if RUN_NOISY_TRAINING:
        execution, benchmark, performance_directory = prepare_torch_execution(
            PROJECT_ROOT, torch_process, counts=WORKER_CANDIDATES
        )
        recovery.snapshot()
        display(benchmark.round(4))
        print("Selected independent optimizer workers:", execution.workers)
    """)
    md("""
    ## 8. Train missing models across all folds

    Jobs interleave folds before entering the worker pool. Gradient requests
    from independent folds/models are stacked into one CUDA tensor operation;
    their losses and gradients stay separate. Each noisy original supplies its
    own fixed teacher before guided/uniform unlearning. Original data rules,
    seed, minibatches, Adam and evaluation metrics remain unchanged.

    START/STEP/30-second heartbeats report real activity. GPU service counters
    show merged requests; final metadata records the largest actual model batch.
    Normal interruption flushes recoverable state. Do not run another writer
    against `collab/torch/` at the same time.
    """)
    code("""
    from src.noisy_training import run_noisy_training, noisy_training_execution
    from tools.torch_noisy_service import torch_training_backend
    from tools.torch_noisy_workflow import torch_completed_models
    from tools.noisy_training_runtime import noisy_training_monitor
    from tools.noisy_workflow import locate_index, progress

    noisy_index = locate_index(PROJECT_ROOT, NOISY_TRAINING_INDEX)
    if RUN_NOISY_TRAINING:
        with torch_training_backend(torch_process), noisy_training_execution(PROJECT_ROOT):
            with torch_completed_models(PROJECT_ROOT), recovery.active():
                with noisy_training_monitor(PROJECT_ROOT, heartbeat_seconds=30):
                    noisy_index = run_noisy_training(
                        primary_study, noisy_problems, historical_inputs, noisy_bindings, execution,
                        setting=training_noise, allow_training=True, force_retrain=FORCE_RETRAIN,
                        performance_directory=performance_directory, progress=progress,
                    )
    print("Noisy study index:", noisy_index)
    """)
    legacy = json.loads((root / "aer_serial.ipynb").read_text(encoding="utf-8"))["cells"]
    start = next(i for i, c in enumerate(legacy) if "## 9. Inspect actual completion" in "".join(c["source"]))
    for cell in legacy[start:]:
        source = "".join(cell["source"])
        source = source.replace("export_bundle(PROJECT_ROOT, UPLOAD_ROOT)", "export_bundle(PROJECT_ROOT, TORCH_DRIVE_ROOT)")
        source = source.replace("from the uploaded Drive folder", "from `MyDrive/collab/torch/`")
        source = source.replace("AER job counters", "GPU service job counters")
        source = source.replace("same GPU/runtime environment", "same PyTorch/CUDA/device/runtime environment")
        cell["source"] = source.splitlines(keepends=True)
        cells.append(cell)
    code("""
    # Close the CUDA process after the training/export cells have finished.
    torch_process.close()
    """)
    notebook = {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python"}, "colab": {"name": "main_project.ipynb", "accelerator": "GPU"},
        "qml_execution": {"engine": "torch_exact_density_autograd_v1", "folds": [0, 1, 2, 3, 4], "single_gpu": True}},
        "nbformat": 4, "nbformat_minor": 4}
    (root / "main_project.ipynb").write_text(json.dumps(notebook, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Wrote {len(cells)} unexecuted cells for single-GPU all-fold training.")


if __name__ == "__main__":
    build()
