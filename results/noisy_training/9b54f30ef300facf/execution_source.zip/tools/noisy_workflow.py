"""Noisy-only execution controls, coverage validation, and a bounded benchmark."""

from dataclasses import asdict
from pathlib import Path
import os

import pandas as pd

from src import artifacts, noisy_training
from src.config import DEFAULT_SEED
from src.execution_resources import memory_budget_mb
from src.models.parallel_aer import AerExecution, gpu_sample, require_gpu


PRIMARY_RATES = (0.05, 0.10, 0.20, 0.30, 0.40, 0.50)
ATTACKS = ("label_flip", "feature_randomization")


def validate_plan(problems, bindings, folds=(0, 1, 2, 3, 4)):
    """Stop before fitting if a rate, attack, fold, model role or budget is missing."""
    folds = tuple(folds)
    expected_names = {"clean"} | {f"{attack}_{100 * rate:g}pct" for attack in ATTACKS for rate in PRIMARY_RATES}
    expected = {(fold, name) for fold in folds for name in expected_names}
    actual = [(problem.fold, problem.name) for problem in problems]
    if len(set(actual)) != len(actual) or set(actual) != expected:
        raise ValueError(f"Noisy conditions differ from the selected protocol: "
                         f"missing={sorted(expected - set(actual))}, extra={sorted(set(actual) - expected)}")
    if bindings.duplicated(["condition", "fold", "role"]).any():
        raise ValueError("Duplicate model roles in the noisy study.")
    expected_roles = {"original", "retrained", "guided", "uniform"}
    for (condition, fold), group in bindings.groupby(["condition", "fold"]):
        if set(group.role) != expected_roles:
            raise ValueError(f"Missing model role for {condition}, fold {fold}.")
    for problem in problems:
        config = problem.config
        if (config.seed != DEFAULT_SEED or config.data.seed != DEFAULT_SEED
                or config.training.steps != 300 or config.training.batch_size != 10
                or config.unlearning.training.steps != 100
                or config.unlearning.alpha != 1.0 or config.unlearning.beta != 1.0
                or config.unlearning.regularization != .01 or config.unlearning.anchor_fraction != .25):
            raise ValueError("The frozen seed/budgets/default unlearning configuration changed.")
        arrays = problem.arrays
        if (len(arrays["train"]) != 268 or len(arrays["validation"]) != 68 or len(arrays["test"]) != 84
                or config.circuit.n_parameters != 72):
            raise ValueError("Noisy training must use the original MNIST420 folds and circuit.")
    plan = noisy_training.training_plan(problems)
    expected_count = 46 * len(folds)  # 20 supervised + 26 unlearning fits per fold.
    if len(plan) != expected_count:
        raise ValueError("Shared reference reuse or model-fit coverage changed.")
    return plan


def prepare_execution(review, problems, historical, bindings, setting, *, selected_index=None, require_gpu_device=True,
                      worker_counts=(5, 8), compatible_benchmark_problems=()):
    """Recover exact existing execution, or check two bounded fresh candidates.

    Selection uses short optimizer throughput and CPU agreement, never test accuracy.
    No density-matrix GPU-shot batching is assumed. The first pinned selection is
    reused on reconnect; an incompatible environment stops without new fitting.
    """
    from tools.noisy_training_runtime import prepare_noisy_execution
    directory = review.root / "results/noisy_training"
    existing = list(directory.glob("*/study.json"))
    has_models = any(next((review.root / "results/runs" / stage).glob("*/manifest.json"), None)
                     for stage in ("noisy_supervised", "noisy_unlearning"))
    if selected_index or existing or has_models:
        return prepare_noisy_execution(review, problems, historical, bindings, setting,
            selected_index=selected_index, require_gpu_device=require_gpu_device,
            compatible_benchmark_problems=compatible_benchmark_problems)
    if require_gpu_device:
        require_gpu()
    cores = os.cpu_count() or 1
    worker_counts = tuple(dict.fromkeys(worker_counts))
    if not worker_counts or any(isinstance(w, bool) or not isinstance(w, int) or w < 1 for w in worker_counts):
        raise ValueError("Worker counts must be positive integers.")
    if require_gpu_device:
        memory = memory_budget_mb(gpu_sample())
        candidates = [AerExecution(device="GPU", workers=workers, threads=min(threads, cores),
                         circuit_batch_size=batch, memory_mb=memory,
                         runtime_binding=False, gpu_parameter_batching=False, gather_ms=10)
                      for workers in worker_counts
                      for threads, batch in ((2, 2048) if workers <= 5 else (4, 4096),)]
    else:
        # Explicit CPU path exists for software fixtures; Colab defaults require GPU.
        candidates = [AerExecution(device="CPU", workers=5, threads=1, circuit_batch_size=1024,
                                   memory_mb=4096, gather_ms=10)]
    print(f"Testing {len(candidates)} bounded configurations; selecting measured optimizer throughput.", flush=True)
    return noisy_training.benchmark_noisy_training(problems[0], setting, review.root,
        candidates=candidates, minimum_workers=min(worker_counts), require_gpu_device=require_gpu_device, probe_steps=1)


def locate_index(root, selected=None):
    root = Path(root).resolve()
    if selected:
        path = (root / selected).resolve()
        if not path.is_relative_to(root):
            raise ValueError("Noisy index leaves this workspace.")
        if not path.is_file():
            raise FileNotFoundError(path)
        return path
    paths = sorted((root / "results/noisy_training").glob("*/study.json"))
    if len(paths) > 1:
        raise ValueError("Multiple noisy attempts exist. Select NOISY_TRAINING_INDEX explicitly.")
    return paths[0] if paths else None


def progress(event):
    print(f"NOISY FITS {event['completed']}/{event['planned']}: "
          f"{event['stage']} {event['key']} [{event['status']}]", flush=True)
