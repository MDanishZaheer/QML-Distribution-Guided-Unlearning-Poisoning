"""Rebuild this upload package's frozen inputs from the completed parent study."""

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import hashlib
import json
import shutil


def digest(file):
    return hashlib.sha256(Path(file).read_bytes()).hexdigest()


def build(project=None):
    destination = Path(__file__).resolve().parents[1]
    project = Path(project).resolve() if project else destination.parent
    relative_index = Path("results/fresh_studies/fa1604cdd38207d9/study.json")
    index = json.loads((project / relative_index).read_text())
    if index.get("complete") is not True:
        raise ValueError("Only completed historical inputs can be packaged.")
    files = {relative_index}
    run_paths = set()
    for entry in index["conditions"].values():
        relative = Path(entry["path"])
        if digest(project / relative) != entry["sha256"]:
            raise ValueError("Condition manifest checksum mismatch.")
        files.add(relative)
        condition = json.loads((project / relative).read_text())
        files.add(Path(condition["split_manifest"]))
        for group in ("models", "unlearned"):
            run_paths.update(Path(path) for path in condition[group].values())
    for relative in sorted(run_paths):
        run = project / relative
        manifest = json.loads((run / "manifest.json").read_text())
        if manifest.get("status") != "complete":
            raise ValueError("Incomplete historical model: " + str(relative))
        files.add(relative / "manifest.json")
        for name, expected in manifest["artifact_sha256"].items():
            file = relative / name
            if not (project / file).resolve().is_relative_to(project) or digest(project / file) != expected:
                raise ValueError("Historical model artifact changed: " + str(file))
            files.add(file)
    destination.mkdir(parents=True, exist_ok=True)
    archive = destination / "historical_inputs.zip"
    hashes = {}
    with ZipFile(archive, "w", ZIP_DEFLATED) as bundle:
        for relative in sorted(files):
            file = project / relative
            hashes[relative.as_posix()] = digest(file)
            bundle.write(file, relative.as_posix())
    manifest = {"study_index": relative_index.as_posix(), "original_source": index["protocol"]["source_fingerprint"],
                "archive_sha256": digest(archive), "files": hashes,
                "scope": "Completed historical numeric inputs only; no new research predictions or fits.",
                "primary_rates": [0.05, 0.10, 0.20, 0.30, 0.40, 0.50], "folds": [0, 1, 2, 3, 4],
                "planned_noisy_fits": 230, "historical_model_runs": len(run_paths)}
    (destination / "input_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    print(f"Packaged {len(files)} verified files from {len(run_paths)} saved fits; "
          f"archive {archive.stat().st_size / 2**20:.1f} MiB. No research execution.")


if __name__ == "__main__":
    build()
