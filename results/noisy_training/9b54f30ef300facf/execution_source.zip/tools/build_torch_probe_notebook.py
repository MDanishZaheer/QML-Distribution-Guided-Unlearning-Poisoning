"""Write the isolated Colab validation notebook without executing it."""

from pathlib import Path
import json
import textwrap


def cell(kind, text):
    value = {"cell_type": kind, "metadata": {},
             "source": (textwrap.dedent(text).strip() + "\n").splitlines(keepends=True)}
    if kind == "code":
        value.update(execution_count=None, outputs=[])
    return value


def build():
    cells = [cell("markdown", """
    # Check the PyTorch noisy-simulator prototype

    This is a synthetic software validation and speed test. It does not load
    MNIST, run the research study, change its settings, or open model checkpoints.
    Use a separate fresh runtime for this benchmark. Keep the existing training
    and recovery folders. The scientific implementation under `src/` is unchanged.

    We compare the actual Qiskit circuit and noisy parameter-shift gradients with
    double-precision PyTorch density-matrix evolution and automatic differentiation.
    The same 72 parameters, gate order, joint two-qubit noise and readout rule apply.
    """), cell("markdown", "## 1. Connect the uploaded folder"), cell("code", """
    from pathlib import Path
    import sys
    from google.colab import drive

    DRIVE_FOLDER = "collab"
    drive.mount("/content/drive")
    UPLOAD_ROOT = Path("/content/drive/MyDrive") / DRIVE_FOLDER
    if not (UPLOAD_ROOT / "tools/torch_density_probe.py").is_file():
        raise FileNotFoundError("Upload the updated tools folder first.")
    sys.path.insert(0, str(UPLOAD_ROOT))
    print("Uploaded folder:", UPLOAD_ROOT)
    """), cell("markdown", """
    ### 1.1 Prepare Aer in this test runtime

    GPU is the default so both simulators can be compared on this same GPU.
    For a CPU runtime, set `AER_DEVICE="CPU"` and `TORCH_DEVICES=("cpu",)`.
    PyTorch is normally supplied by Colab; this notebook does not install it.
    If the pinned Aer installer requests a restart, restart the session and Run all.
    """), cell("code", """
    from tools.colab_bootstrap import install_dependencies

    AER_DEVICE = "GPU"
    TORCH_DEVICES = ("cpu", "cuda")
    install_dependencies(UPLOAD_ROOT, device=AER_DEVICE)
    """), cell("markdown", """
    ## 2. Copy code to a separate local test directory

    Only code and the archived dependency file are copied. No historical model
    archive, dataset, training result or optimizer checkpoint is needed.
    """), cell("code", """
    import os
    import shutil

    LOCAL_ROOT = Path("/content/qml_torch_noise_probe").resolve()
    if "src" in sys.modules:
        raise RuntimeError("Restart the session before rerunning the complete setup.")
    LOCAL_ROOT.mkdir(parents=True, exist_ok=True)
    for name in ("src", "tools"):
        shutil.copytree(UPLOAD_ROOT / name, LOCAL_ROOT / name, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copyfile(UPLOAD_ROOT / "requirements.txt", LOCAL_ROOT / "requirements.txt")
    sys.path.insert(0, str(LOCAL_ROOT))
    os.chdir(LOCAL_ROOT)
    """), cell("markdown", "## 3. Check the actual runtime"), cell("code", """
    import torch
    import qiskit_aer
    import pandas as pd
    from IPython.display import display
    from tools.cpu_folds import allocated_cores

    if AER_DEVICE not in qiskit_aer.AerSimulator().available_devices():
        raise RuntimeError("The selected Aer device is unavailable. No fallback was used.")
    if "cuda" in TORCH_DEVICES and not torch.cuda.is_available():
        raise RuntimeError("PyTorch CUDA is unavailable in this runtime.")
    display(pd.Series({"torch": torch.__version__, "aer": qiskit_aer.__version__,
        "aer_device": AER_DEVICE, "allocated_cpu_cores": allocated_cores(),
        "gpu": torch.cuda.get_device_name() if torch.cuda.is_available() else None}))
    """), cell("markdown", """
    ## 4. Set a small reproducible probe

    Seed 6304 creates synthetic features and targets. Test ordinary and extreme
    inputs, initialized and rotated weights, noise variants, guided/uniform
    objectives, independent model batches and short Adam trajectories.
    Representative gradient timings use batch 10 with one and five models.
    """), cell("code", """
    from datetime import datetime, timezone

    REPEATS = 3
    MODEL_COUNTS = (1, 5)
    CPU_THREADS = min(2, allocated_cores())
    probe_name = "colab_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    PROBE_OUTPUT = LOCAL_ROOT / "benchmarks/torch_noise" / probe_name
    print("Synthetic probe output:", PROBE_OUTPUT)
    """), cell("markdown", """
    ## 5. Run correctness checks and timed gradient calls

    The comparison checks density matrices, probabilities, losses, all 72 gradient
    components, finite differences, and short Adam weight/moment trajectories.
    Warmup is excluded and CUDA is synchronized. Timing includes input transfers
    and returning losses/gradients to CPU. Each model keeps its own gradient;
    batch losses are summed rather than dividing gradients by the model count.

    These timings exclude production checkpoint uploads and full-study orchestration.
    A failed numerical check prevents recommending adoption.
    """), cell("code", """
    from tools.benchmark_torch_noise import run

    probe_report = run(PROBE_OUTPUT, torch_python=sys.executable,
        devices=TORCH_DEVICES, threads=CPU_THREADS, repeats=REPEATS,
        model_counts=MODEL_COUNTS, aer_device=AER_DEVICE)
    print("Numerical validation:", probe_report["status"])
    """), cell("markdown", """
    ## 6. Compare measured speed and accuracy

    Ratios compare loss-and-gradient calls with the recorded Aer device. They
    are not complete-study speedups or research findings. Keep CPU and CUDA
    results separate. A twofold speedup is a provisional engineering threshold,
    not a statistical significance test or a promise about full training time.
    """), cell("code", """
    timings = pd.DataFrame(probe_report["timings"])
    display(timings.round(4))
    checks = pd.DataFrame(probe_report["checks"])
    error_columns = [c for c in checks if c.endswith("max_error")]
    display(checks.groupby("device")[error_columns].max())
    selected = timings[timings.models == 5]
    display(selected.groupby("device").speedup.min().rename("minimum_five_model_speedup"))
    """), cell("markdown", """
    ## 7. Save the software-test evidence

    Copy only the new benchmark evidence into a new Drive folder. Existing
    research results and recovery stores remain unchanged. Download this folder
    to compare with the local test before adopting a production training backend.
    Partial Aer optimizers are not converted by this notebook.
    """), cell("code", """
    saved_probe = UPLOAD_ROOT / "benchmarks/torch_noise" / probe_name
    shutil.copytree(PROBE_OUTPUT, saved_probe)
    print("Saved benchmark evidence:", saved_probe)
    print("Summary:", saved_probe / "report.json")
    """)]
    path = Path(__file__).resolve().parents[1] / "benchmark_pytorch_noise.ipynb"
    notebook = {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python"}, "colab": {"name": path.name},
        "qml_probe": {"synthetic_only": True, "production_training": False}}, "nbformat": 4, "nbformat_minor": 4}
    path.write_text(json.dumps(notebook, indent=1) + "\n", encoding="utf-8")
    print("Wrote", path.name, "without executing it.")


if __name__ == "__main__":
    build()
