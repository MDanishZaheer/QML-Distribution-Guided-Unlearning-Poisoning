# Noisy quantum training and unlearning

Upload this complete `collab` folder directly to Google Drive's `MyDrive`.
Select **one T4 GPU runtime (16 GiB)** and Run all in **`main_project.ipynb`**.
Independent optimizers from **all five folds run concurrently**, with gradient
requests combined into real PyTorch CUDA tensor batches in one persistent GPU
process. The five separate fold notebooks are not needed for this run.
If you rename/move the folder, edit `DRIVE_FOLDER` in the first code cell.
Dependency installation may request one session restart; restart and run all
again. No research models have been trained by creating this package.

Keep existing recovery/results folders when uploading updated code. Stop old
writers first. New durable state goes to **`MyDrive/collab/torch/`**; fast working
files and inputs use runtime-local disk. Do not run two writers against that
store. The parent project's code/notebook/results are unchanged.

## Running the full study on one T4

1. Upload the full folder, including `historical_inputs.zip`, `input_manifest.json`,
   `src/`, `tools/`, `requirements.txt` and the new `main_project.ipynb`.
2. Select a T4 GPU, open `main_project.ipynb`, and Run all. Aer CPU supplies the
   numerical oracle; training uses PyTorch CUDA. Existing PyTorch is checked
   rather than automatically upgraded. Missing CUDA stops before fitting.
3. Keep all five folds and `FORCE_RETRAIN=False`. Fresh setup checks synthetic
   correctness and measures 5/10/20 independent optimizer workers. The fastest
   passing measured configuration is pinned for continuation.
4. Watch START/STEP and 30-second heartbeats. GPU job counters and the largest
   concurrent gradient model batch report real activity. Each model keeps its
   own weights, minibatch RNG, Adam moments and best-weight selection. Gradients
   are not averaged across independent models.
5. A later session with the same runtime identity resumes verified PyTorch
   Adam/RNG state. Atomic local commits follow every complete update; Drive
   mirrors every five seconds and flushes on normal interruption. Abrupt VM loss
   can lose updates since the last verified upload. Completed archives are
   verified before completion is reported.
6. Download **`MyDrive/collab/torch/noisy_models_results.zip`** after export. Keep
   `torch/recovery/` until the full results import is verified.

The protocol still plans **230 fits: 100 supervised + 130 unlearning**, covering
clean and both attacks at 5/10/20/30/40/50% across five folds. The 25% support
conditions remain outside noisy training. The circuit, exact synthetic channel,
seed 6304, frozen inputs, batch size 10, 300/100 updates, NumPy Adam and metrics
remain the same. Complex128 density evolution and float64 automatic
differentiation replace parameter-shift expansion. This engine change is
explicit in execution/optimizer identities and archived helper source.

The first handoff reads the latest stopped CPU-fold plan, GPU-fold plan, or
serial recovery, in that order. `IMPORT_SOURCE` can explicitly select one.
Completed fits require verified source/input/protocol/artifact records and
retain their actual device, source and environment. Frozen teachers are reused
only with matching original weights and memberships. **Partial Aer Adam states
do not resume in PyTorch.** The explicit `RESTART_UNFINISHED_AER=True` starts
replacements normally while recording source steps/hashes. Old recovery stores
are read-only. Set it False to stop on partial Aer fits. An optimizer-only
download without manifests/index/model archives cannot verify finished models;
restore the full recovery folder first. `IMPORT_SOURCE="none"` deliberately
starts without older imports.

Model concurrency is separate from the training minibatch size. Prediction
rows are chunked separately. CUDA out-of-memory retries split independent
model groups while preserving each logical update. No artificial allocation
fills VRAM. Allocated and reserved GPU memory are reported separately, following
[PyTorch's memory documentation](https://docs.pytorch.org/docs/stable/notes/cuda.html#memory-management).
Actual T4 throughput is measured at startup; the RTX 3060 timings below are
not a T4 or full-study runtime prediction.

The previous Aer alternatives remain available as `aer_serial.ipynb`, separate
GPU fold notebooks and CPU notebooks. They use separate recovery stores and
are outside the one-T4 Run all flow.

Integration verification: all 51 synthetic tests passed, followed by a fresh
seven-test CUDA recheck after final runtime settings were applied. A separate
local sizing smoke check successfully merged 20 model gradients into one CUDA
batch without memory splitting. These checks used the laptop RTX 3060, not a
T4. The report and exact helper source are saved in
`benchmarks/torch_noise/integration/validation.json` and `validated_source/`.
No notebook or real research study was executed locally.

## PyTorch noisy-simulator prototype

`benchmark_pytorch_noise.ipynb` is a separate synthetic correctness and speed
probe. Upload this notebook and the updated `tools/` folder, then run it in a
fresh Colab test runtime. It does not load MNIST, open or migrate optimizer
checkpoints, run the research study, or change any existing execution flags.
It exports the real Qiskit circuit schedule and checks double-precision PyTorch
automatic differentiation against Aer's exact noisy parameter shifts.

The local Windows test used the existing QML interpreter for Aer CPU and the
existing ATML interpreter for PyTorch CPU/CUDA. No dependency was installed.
PyTorch CUDA successfully used the laptop's RTX 3060. Both CPU comparisons
used two CPU threads; CUDA also used complex128/float64. All 52 device/case
checks passed across the initial and extended validations: full density
matrices, physical-state checks, predictions, losses, all 72 gradients,
finite differences, independent model batches, guided/uniform targets,
zero-anchor/zero-penalty controls, and short supervised/unlearning Adam
weight/moment trajectories. These are software checks, not research findings.

Representative median times for five models, each with batch size 10:

| Loss/gradient call | Aer CPU | PyTorch CPU | PyTorch CUDA | CUDA / Aer CPU speedup |
|---|---:|---:|---:|---:|
| Supervised | 22.6802 s | 1.4442 s | 0.1375 s | 164.94x |
| Unlearning, forget plus anchors | 43.2082 s | 2.4235 s | 0.2898 s | 149.10x |

Times include returning CPU gradients and CUDA input transfers, with warmup
excluded and CUDA synchronized. They exclude Adam arithmetic, full validation
evaluation and production checkpoint/storage overhead. The local Aer build
exposes CPU only; this is not an Aer GPU comparison or a full-study runtime
estimate. Peak allocated CUDA memory was about 715 MiB for the supervised
five-model call and 1394 MiB for unlearning. Do not extrapolate from memory
occupancy alone.

The exact reports, synthetic cases and archived source are under
`benchmarks/torch_noise/initial/` and `benchmarks/torch_noise/extended_validation/`.
`benchmarks/torch_noise/summary.json` combines the evidence. Maximum probability
error was 6.67e-16, gradient error 2.21e-16, and short Adam weight discrepancy
1.03e-12. The mathematical prototype class remains identical to its archived
tested sources. At the end of prototype validation, scientific source,
requirements and existing notebooks retained all 102 protected file hashes.
Subsequent integration deliberately replaces this package's main notebook and
execution helpers; scientific `src/` and `requirements.txt` remain unchanged.

The integrated main notebook retains the full study and performs its own short
Aer-CPU numerical check and GPU batching selection. The optional Colab probe
compares with Aer GPU on the allocated GPU. No cross-backend partial optimizer
continuation is enabled. Integration tests cover batched full-circuit
gradients, exact interrupted Adam/RNG continuation, two-fold execution, Drive
recovery, completed Aer model reuse and partial Aer preservation. These
synthetic checks are not research results.

To reproduce the local probe using existing environments, from this folder:

```text
C:/Users/DanishZaheer/anaconda3/envs/QML/python.exe -X utf8 -B -m tools.benchmark_torch_noise --output benchmarks/torch_noise/new_probe --torch-python C:/Users/DanishZaheer/anaconda3/envs/ATML/python.exe --devices cpu cuda --threads 2 --repeats 3 --model-counts 1 5
```

## Moving to five CPU runtimes

1. Stop the GPU training cell normally and wait for checkpoint backups to
   finish. Keep the current `recovery/`, any `parallel/`, `results/`, `src/`,
   `requirements.txt`, and historical input archive on Drive.
2. Replace the uploaded **`tools/` folder** with the updated local copy. Add
   `cpu_parallel_setup.ipynb`, `train_cpu_fold_0.ipynb` through
   `train_cpu_fold_4.ipynb`, and `cpu_parallel_results.ipynb`. Do not replace
   the whole existing Drive folder with an empty local results folder.
3. Select a **CPU runtime**, then Run all in `cpu_parallel_setup.ipynb` once.
   Setup reads the stopped serial recovery, or the newer GPU fold stores when
   a GPU parallel plan exists. It verifies the experiment and copies completed
   models into separate `parallel_cpu/fold_N/` stores. The original GPU stores
   are read-only throughout this handoff.
4. Setup explicitly sets `RESTART_UNFINISHED_ON_CPU=True`. This reuses complete
   GPU models but starts CPU replacements for unfinished GPU models from the
   normal seed initialization. **Partial GPU Adam/RNG states do not resume on
   CPU.** Their exact original bytes remain at their source, with checkpoint
   hashes and saved step counts in the CPU handoff audit. Set the flag False
   to stop setup when partial source fits exist. Completed fits are not forced
   to retrain. To retain those unfinished updates as a continuation, finish
   them in their matching GPU environment before making the CPU handoff.
5. Open each `train_cpu_fold_N.ipynb` in its **own independent CPU runtime**.
   Begin with two, inspect the printed throughput benchmark, and add the other
   folds if your account can allocate them. Use one writer per fold. Extra
   tabs on the same runtime share its resources. No number of concurrent
   Colab runtimes is guaranteed by this package.
6. Keep `FORCE_RETRAIN=False` and Run all. Each fold still has 20 supervised
   and 26 unlearning fits. Worker/thread choices are bounded by CPU affinity
   and cgroup quota, with at most three benchmark candidates. Aer execution
   is CPU density-matrix simulation of the unchanged synthetic noise model.
   There is no GPU requirement or VRAM target. More RAM alone does not speed
   these small circuits; actual updates per second determine the selection.
7. Reconnect using the same CPU packages and execution settings. New CPU fits
   resume their own strict full Adam/RNG checkpoints. Completed imports keep
   their original source/environment/device identities; new fits record the
   actual CPU runtime. Changed scientific settings never reuse a cached model.
8. After all five finish, Run all in `cpu_parallel_results.ipynb`. It verifies
   saved artifacts and exports `MyDrive/collab/cpu_parallel_noisy_models_results.zip`.
   It never fits models or generates missing predictions. The aggregate keeps
   per-fold CPU execution provenance and the immutable imported-model provenance.

CPU notebooks install `qiskit-aer` at the same pinned Aer version, replacing
the GPU wheel in the runtime only. The archived `requirements.txt` remains
unchanged so historical source hashes stay valid. The installer refuses to
continue with mixed imported package versions and requests a restart when
needed. See the official [Aer installation instructions](https://pypi.org/project/qiskit-aer/0.18.4/).
The CPU helper and its handoff audit are execution support outside `src/`;
they do not relax the optimizer's identity checks. CPU speed relative to your
GPU run is unmeasured until the runtime benchmark executes.

## Moving an existing run to five GPU runtimes

1. Interrupt the old training cell normally and wait for checkpoint backups to
   finish. Keep its `recovery/`, `results/`, input archive, source and packages.
2. Replace the **`tools/` folder** in the existing `MyDrive/collab/` with this
   updated copy. Add the seven new notebooks: `parallel_setup.ipynb`,
   `train_fold_0.ipynb` through `train_fold_4.ipynb`, and
   `parallel_results.ipynb`. Do not replace or delete existing recovery folders.
3. Restart the coordinator session and run `parallel_setup.ipynb`. It verifies
   the original saved study and reads the old recovery without writing to it.
   Completed archives, full Adam/RNG states, fixed teachers and compatible
   benchmark records are copied into their assigned fold stores. Its table
   reports actual copied coverage. Running setup again retains existing fold
   progress instead of reseeding it.
4. Open each fold notebook in its **own independent GPU runtime** and Run all.
   Start with two to confirm resource allocation/combined throughput, then add
   the other three if available. Use one writer for each fold. Opening several
   tabs on the same runtime adds no GPU capacity.
5. Keep `FORCE_RETRAIN=False`. Existing attempts pin their recorded execution;
   use the matching GPU type, driver/runtime and packages for unfinished fits.
   A mismatch stops without silently restarting. Fresh folds benchmark the
   `FRESH_WORKER_COUNTS=(5, 8)` candidates; adjust only before fresh fitting.
6. After all five runners finish, run `parallel_results.ipynb`. It verifies
   saved artifacts, combines tables and displays all generated plots, then
   writes `MyDrive/collab/parallel_noisy_models_results.zip`. Download that ZIP
   for import into the parent project. The full folder can also be downloaded.

Each fold plans **20 supervised + 26 unlearning = 46 fits**, totaling 230.
Workers train different models; a single model's optimizer updates stay ordered.
Unlearning waits for the fold's supervised originals/retraining references and
newly frozen noisy teachers. Completed compatible fits load; partial fits
resume their own saved state. No old trained model is relabelled as a new run.

The five stores are `parallel/fold_0/` through `parallel/fold_4/`. Each owns its
own `recovery/state.zip`, completed-model catalog, optimizer backups, and
`noisy_models_results.zip`. The top-level `parallel/plan.json` is a one-time
handoff record, not a shared progress file. One fold never writes another
fold's outputs. Do not launch the same fold runner twice concurrently.

The final collector defaults to `REQUIRE_COMPLETE=True`. An explicit partial
review still reports all five planned folds and missing coverage. It preserves
each fold's actual source/environment/execution provenance and creates a review
aggregate that cannot be used as an optimizer-continuation identity. Repeated
collection verifies existing model bytes and preserves prior source audits.
No missing prediction is generated or filled in by the collector.

The notebook runs only the missing noisy-training study: clean plus label
flipping and full-vector Gaussian feature randomization at 5%, 10%, 20%, 30%,
40%, and 50%, across folds 0–4. The user selected the original primary rates;
25% remains noiseless ablation support and there is no saved 15% condition.
There are 100 unique supervised fits and 130 guided/uniform unlearning fits.
Shared retained-data retraining references are fitted once per unique problem.
Original parameter sweeps and the completed fixed-weight noise sweep are not repeated.

Keep seed 6304, 300 supervised updates, batch size 10, 100 unlearning updates,
the original six-qubit circuit, exact saved memberships and frozen numeric PCA
features. Noisy supervised fits start from the original seed initialization;
guided/uniform fits start from their new noisy original and use newly frozen
noisy teachers. The default alpha=1, lambda=0.01, beta=1 and anchor_fraction=0.25
stay fixed. Training integrates combined synthetic noise exactly: one-qubit
depolarizing strength 0.01, two-qubit strength 0.02 and readout flips 0.01.
These are Aer channel parameters, not hardware-calibrated error rates.

## Files and storage

- `src/`: a separate copy of the existing scientific implementation.
- `tools/`: notebook setup, short execution selection, progress and durable recovery.
- `historical_inputs.zip` / `input_manifest.json`: verified saved inputs and original provenance.
- `requirements.txt`: archived Linux GPU pins; CPU notebooks explicitly substitute the CPU Aer wheel at the same version.
- `tests/`: synthetic CPU software checks; never reported as research results.

Saved historical inputs are copied/extracted/verified on runtime-local disk.
No dataset download or preprocessing fit occurs. For the GPU runners, the two short benchmark
candidates use 5 and 8 optimizer workers sharing one batched Aer service, with
independent fold/model states. The benchmark checks correctness and measures
update throughput. It is not a full worker/batch Cartesian sweep, and high
VRAM occupancy is not promised or used as the speed criterion. GPU operation is
required by the GPU notebooks; CPU notebooks explicitly select CPU execution.

Each complete optimizer update is atomically saved locally. A verified Drive
checkpoint generation is published every five seconds, initially, and on normal
exit. Sudden VM loss can lose updates since the latest successful backup.
Completed model archives are verified on Drive before completion is reported.
`recovery/state.zip` keeps a small metadata snapshot, with a previous verified
generation; `recovery/models/` keeps completed-model archives. This avoids
repeatedly scanning thousands of historical Drive files. Strict source,
environment, execution and data matching remain mandatory for optimizer resume.
Keep `FORCE_RETRAIN=False`; a changed runtime stops instead of silently resetting.

Routine metadata updates now use one background uploader that merges repeated
save requests. No Drive upload holds the shared model-start lock. Each optimizer
still waits for verified identity/source/reference metadata before starting;
each completed model still waits for its verified archive and catalog before
DONE is reported. Completed-model metadata is recovered from its own archive,
so it is no longer duplicated in every routine snapshot. The original
version-1 recovery archives and five-second Adam/RNG backups remain supported.
This reduces storage waiting; actual GPU/Drive throughput must be measured.

For a storage-only update of the serial alternative, replace **only
`tools/noisy_drive.py`** in
the same uploaded Drive folder. Interrupt the running cell normally and wait
for it to stop and finish its checkpoint backups before replacing the file.
Keep `recovery/`, `results/`, the original input archive, `src/`, package versions
and execution settings. Use **Runtime > Restart session**, then **Run all** with
`FORCE_RETRAIN=False`. The staging cell copies the updated helper locally;
recovery loads completed fits and resumes unfinished fits from their latest
verified Adam/RNG backup. A sudden VM loss can still discard the unfinished
update and updates newer than that backup. Do not delete the runtime or start
from a new empty Drive folder as part of this update. The five-runtime upgrade
requires the complete updated `tools/` folder and seven new notebooks as listed
under "Moving an existing run to five GPU runtimes" above.

START/STEP messages, 30-second heartbeats, local checkpoint steps and Aer job
counters distinguish training from storage/evaluation. Possible stalls save
thread stacks after ten minutes without observed changes; no progress is invented.
The final `noisy_models_results.zip` is written and read-back-verified in this
same Drive folder. Download it for later import. It contains conventional
relative result paths, completed/partial models, checkpoints, code provenance,
and actual exported tables/figures. Keep `recovery/` until import is verified.

To reconnect, open the same folder and run all with the same GPU/runtime,
source and package versions. To review after completion, set
`RUN_NOISY_TRAINING=False`. A missing or incompatible input stops without
repeating noiseless training. Existing parent project code/results are unchanged.

The package intentionally contains the full completed historical input study,
including 25% support artifacts needed to verify its original index; the selected
noisy study excludes those conditions. Original Linux/NVIDIA L4 provenance is
retained. New noisy runs record the actual runtime used for this execution.

GPU package and execution options follow the official
[Aer installation instructions](https://pypi.org/project/qiskit-aer-gpu/) and
[AerSimulator documentation](https://qiskit.github.io/qiskit-aer/stubs/qiskit_aer.AerSimulator.html).
Runtime parameter/GPU-shot batching are disabled for the exact density-matrix
optimizer; no statevector-only speedup is assumed.

Synthetic checks, using an environment with the dependencies already installed:

```text
python -B -m unittest discover -s tests -v
```

Package verification: 44 small synthetic CPU software checks passed, covering
noisy gradients, independent parallel optimization, interrupted Adam/RNG resume,
fresh-VM recovery, completed-model reuse without fitting, and result exports.
Transport checks also cover slow uploads without a blocked model-start lock,
coalesced metadata saves, no premature completion, backup-error propagation,
and compatibility with the earlier version-1 recovery snapshots.
Parallel checks cover a read-only handoff, exact reuse of completed model and
prediction bytes, continuation of partial Adam/RNG states in assigned folds,
strict environment rejection, idempotent preparation/collection, and combined
metrics matching the original synthetic multi-fold study. The actual saved
historical inputs were checked separately: all five folds have 13 primary
conditions and exactly 20 supervised plus 26 unlearning fits.
The archived inputs were independently loaded in a fitting-blocked check and
produced exactly the selected 100-supervised/130-unlearning plan. The notebook
remains unexecuted. Actual Colab GPU throughput and Drive behavior are checked
when you run it; no research result or GPU timing was generated during packaging.

CPU checks additionally verify completed-model reuse across recorded environments
without fitting, exact teacher reuse, immutable original recovery bytes, explicit
restarts for partial source fits, strict CPU Adam/RNG continuation, CPU notebook
device selection, CPU wheel selection, quota-aware candidates, and combined saved
metrics. CPU helper source/provenance is archived separately under
`results/noisy_training/runtime_support/cpu_folds/`. No Colab CPU throughput or
new research score has been measured locally.
