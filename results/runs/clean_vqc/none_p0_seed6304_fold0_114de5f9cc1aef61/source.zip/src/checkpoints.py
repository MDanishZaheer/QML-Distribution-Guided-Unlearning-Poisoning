"""Select per-model runs and preserve the state needed to resume local training."""

from dataclasses import dataclass, field
from pathlib import Path

from src.artifacts import (create_run, fingerprint, json_value, load_json,
                           load_run, save_json)


def matching_manifests(directory, identity):
    """Newest attempt first, independent of random directory-name suffixes."""
    matches = []
    for file in Path(directory).glob("*/manifest.json"):
        manifest = load_json(file)
        if manifest.get("identity") == json_value(identity):
            matches.append((file.parent, manifest))
    return sorted(matches, key=lambda item: item[1]["created_utc"], reverse=True)


@dataclass
class CheckpointSession:
    """A notebook execution session; force each distinct fitting problem only once.

    Recreate this object when starting another forced experiment. Sharing it
    across conditions avoids retraining the same clean reference repeatedly.
    Existing completed run folders remain immutable research records. The
    active_checkpoints.json index is replaced atomically as active models change.
    """

    force_retrain: bool = False
    _runs: dict = field(default_factory=dict, init=False, repr=False)

    def owns(self, run):
        return run is not None and Path(run["path"]).resolve() in self._runs.values()

    def open(self, directory, identity, *, allow_execution, reuse=True, slot=None):
        """Return (path, completed_result), or (None, None) when execution is off."""
        directory = Path(directory).resolve()
        key = (str(directory), fingerprint(identity))
        path = self._runs.get(key)
        if path is None and reuse and not self.force_retrain:
            matches = matching_manifests(directory, identity)
            if matches:
                path = matches[0][0]
        if path is not None:
            manifest = load_json(path / "manifest.json")
            if manifest["status"] == "complete":
                result = load_run(path)  # Verify artifact checksums before reuse.
                self._runs[key] = path
                if allow_execution:
                    self._activate(directory, slot, identity, path)
                return path, result
        if not allow_execution:
            return None, None
        if path is None:
            path, _ = create_run(directory, identity, reuse=False)
        else:
            manifest.update(status="running", resumed=True)
            manifest.pop("error", None)
            manifest.pop("finished_utc", None)
            save_json(path / "manifest.json", manifest)
        self._runs[key] = path
        self._activate(directory, slot, identity, path)
        return path, None

    @staticmethod
    def _activate(directory, slot, identity, path):
        slot = slot or {"identity": fingerprint(identity)}
        index_file = directory / "active_checkpoints.json"
        index = load_json(index_file) if index_file.exists() else {}
        index[fingerprint(slot)[:24]] = {
            "slot": slot, "identity": fingerprint(identity), "run": path.name,
        }
        save_json(index_file, index)


def training_streams(model, random):
    """Callbacks for minibatch RNG, Aer sampling RNG, and accumulated resources."""
    def capture():
        return {"minibatch_rng": random.bit_generator.state,
                "simulator_rng": model.executor.random.bit_generator.state,
                "resources": dict(model.executor.stats),
                "job_ids": list(model.executor.job_ids),
                "actual_device": model.executor.actual_device}

    def restore(state):
        if state["actual_device"] != model.executor.actual_device:
            raise ValueError("Checkpoint device changed; start a fresh run with FORCE_RETRAIN=True.")
        random.bit_generator.state = state["minibatch_rng"]
        model.executor.random.bit_generator.state = state["simulator_rng"]
        model.executor.stats = dict(state["resources"])
        model.executor.job_ids = list(state["job_ids"])

    return capture, restore
